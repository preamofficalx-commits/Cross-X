package com.example.crosshair

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

object Theme {
    val BG = Color.parseColor("#0A0F1C")
    val CARD = Color.parseColor("#121A2C")
    val STROKE = Color.parseColor("#22304D")
    val ACCENT = Color.parseColor("#2DE2B6")
    val VIOLET = Color.parseColor("#7C5CFF")
    val DANGER = Color.parseColor("#FF4D6D")
    val TEXT = Color.parseColor("#FFFFFF")
    val MUTED = Color.parseColor("#8B97B5")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun rounded(fill: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius
        setColor(fill)
        if (strokeW > 0) setStroke(strokeW, stroke)
    }
