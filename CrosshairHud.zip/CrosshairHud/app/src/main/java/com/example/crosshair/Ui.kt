package com.example.crosshair

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.view.View

object Theme {
    val BG0 = Color.parseColor("#060A13")
    val BG1 = Color.parseColor("#0D1526")
    val CARD = Color.parseColor("#111B30")
    val CARD2 = Color.parseColor("#17243F")
    val STROKE = Color.parseColor("#23324F")
    val ACCENT = Color.parseColor("#2DE2B6")
    val ACCENT2 = Color.parseColor("#3C8DFF")
    val VIOLET = Color.parseColor("#7C5CFF")
    val DANGER = Color.parseColor("#FF4D6D")
    val WARN = Color.parseColor("#FFB84D")
    val TEXT = Color.WHITE
    val MUTED = Color.parseColor("#8B97B5")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun rounded(fill: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius
        setColor(fill)
        if (strokeW > 0) setStroke(strokeW, stroke)
    }

fun gradient(
    c1: Int,
    c2: Int,
    radius: Float,
    orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT
): GradientDrawable =
    GradientDrawable(orientation, intArrayOf(c1, c2)).apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius
    }

/** พื้นหลังตารางจางๆ สำหรับกล่องตัวอย่างเป้า */
class GridBackdrop(context: Context) : View(context) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#14FFFFFF")
        strokeWidth = 1f
    }
    private val axis = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#26FFFFFF")
        strokeWidth = 1.5f * d
    }

    override fun onDraw(c: Canvas) {
        val step = 24f * d
        var x = width / 2f % step
        while (x < width) {
            c.drawLine(x, 0f, x, height.toFloat(), p)
            x += step
        }
        var y = height / 2f % step
        while (y < height) {
            c.drawLine(0f, y, width.toFloat(), y, p)
            y += step
        }
        c.drawLine(width / 2f, 0f, width / 2f, height.toFloat(), axis)
        c.drawLine(0f, height / 2f, width.toFloat(), height / 2f, axis)
    }
}
