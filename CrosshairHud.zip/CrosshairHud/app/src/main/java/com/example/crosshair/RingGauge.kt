package com.example.crosshair

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** มาตรวงกลม: มีชื่อ ค่า และแถบสีเปลี่ยนตามระดับ (invert = true ใช้กับแบต: ยิ่งต่ำยิ่งแดง) */
class RingGauge(
    context: Context,
    private val name: String,
    private val baseColor: Int,
    private val invert: Boolean = false
) : View(context) {

    private val d = resources.displayMetrics.density
    private var shown = 0f
    private var valueText = "—"
    private var ringColor = baseColor
    private var anim: ValueAnimator? = null
    private val rect = RectF()

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Theme.STROKE
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        color = Color.WHITE
    }
    private val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        color = Theme.MUTED
    }

    fun update(text: String, pct: Int?) {
        valueText = text
        val target = (pct ?: 0).coerceIn(0, 100).toFloat()
        ringColor = when {
            pct == null -> Theme.STROKE
            invert -> if (pct <= 15) Theme.DANGER else if (pct <= 30) Theme.WARN else baseColor
            else -> if (pct >= 85) Theme.DANGER else if (pct >= 65) Theme.WARN else baseColor
        }
        anim?.cancel()
        val from = shown
        val a = ValueAnimator.ofFloat(from, target)
        a.duration = 350
        a.addUpdateListener {
            shown = it.animatedValue as Float
            invalidate()
        }
        anim = a
        a.start()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val size = MeasureSpec.getSize(w)
        setMeasuredDimension(size, size)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val stroke = w * 0.085f
        track.strokeWidth = stroke
        arc.strokeWidth = stroke
        arc.color = ringColor
        val inset = stroke / 2f + 2f * d
        rect.set(inset, inset, w - inset, w - inset)
        c.drawArc(rect, 135f, 270f, false, track)
        if (shown > 0.5f) c.drawArc(rect, 135f, 270f * shown / 100f, false, arc)
        valuePaint.textSize = w * 0.22f
        namePaint.textSize = w * 0.125f
        c.drawText(valueText, w / 2f, w * 0.52f, valuePaint)
        c.drawText(name, w / 2f, w * 0.88f, namePaint)
    }
}
