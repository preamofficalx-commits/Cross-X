package com.example.crosshair

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** อัดหน้าจอด้วย MediaProjection + MediaRecorder แล้วเก็บไว้ที่ Movies/CrosshairHud */
class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.example.crosshair.REC_START"
        const val ACTION_STOP = "com.example.crosshair.REC_STOP"

        @Volatile var recording = false
        @Volatile var startedAt = 0L
        @Volatile var message = ""
    }

    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var outUri: Uri? = null
    private var outFile: File? = null
    private var pfd: ParcelFileDescriptor? = null
    private var fileName = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACTION_START -> {
                if (!recording) startRecording(intent)
            }
            ACTION_STOP -> {
                if (recording) stopRecording()
                stopSelf()
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (recording) stopRecording()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun startRecording(intent: Intent) {
        val prefs = getSharedPreferences("crosshair", MODE_PRIVATE)
        val mic = prefs.getBoolean("rec_mic", false) &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        startAsForeground(mic)
        message = ""
        try {
            val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
            val data = intent.getParcelableExtra<Intent>("data")
                ?: throw IllegalStateException("ไม่ได้รับสิทธิ์อัดหน้าจอ")
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data)
                ?: throw IllegalStateException("เริ่ม MediaProjection ไม่ได้")
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    if (recording) stopRecording()
                    stopSelf()
                }
            }, handler)

            // ---- คำนวณขนาดวิดีโอ ----
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            var w = dm.widthPixels
            var h = dm.heightPixels
            val orient = prefs.getInt("rec_o", 0) // 0 ตามหน้าจอ, 1 แนวนอน, 2 แนวตั้ง
            if ((orient == 1 && w < h) || (orient == 2 && w > h)) {
                val t = w
                w = h
                h = t
            }
            val quality = prefs.getInt("rec_q", 1) // 0 = 720p, 1 = 1080p, 2 = ต้นฉบับ
            val target = when (quality) {
                0 -> 720
                1 -> 1080
                else -> 0
            }
            val shortSide = minOf(w, h)
            if (target > 0 && shortSide > target) {
                val scale = target.toFloat() / shortSide
                w = (w * scale).toInt()
                h = (h * scale).toInt()
            }
            w = w and 1.inv()
            h = h and 1.inv()
            val bitrate = when (quality) {
                0 -> 6_000_000
                1 -> 10_000_000
                else -> 14_000_000
            }

            // ---- เตรียมตัวอัด ----
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder = rec
            if (mic) rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            openOutput(rec)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (mic) {
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                rec.setAudioEncodingBitRate(128_000)
                rec.setAudioSamplingRate(44100)
            }
            rec.setVideoSize(w, h)
            rec.setVideoFrameRate(30)
            rec.setVideoEncodingBitRate(bitrate)
            rec.prepare()

            display = proj.createVirtualDisplay(
                "CrosshairRec", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                rec.surface, null, null
            )
            rec.start()
            startedAt = SystemClock.elapsedRealtime()
            recording = true
        } catch (e: Exception) {
            recording = false
            message = "เริ่มอัดไม่สำเร็จ: " + (e.message ?: e.javaClass.simpleName)
            release(true)
            stopSelf()
        }
    }

    private fun openOutput(rec: MediaRecorder) {
        fileName = "Crosshair_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/CrosshairHud")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("สร้างไฟล์วิดีโอไม่สำเร็จ")
            outUri = uri
            val fd = contentResolver.openFileDescriptor(uri, "w")
                ?: throw IllegalStateException("เปิดไฟล์วิดีโอไม่สำเร็จ")
            pfd = fd
            rec.setOutputFile(fd.fileDescriptor)
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            dir.mkdirs()
            val f = File(dir, fileName)
            outFile = f
            rec.setOutputFile(f.absolutePath)
        }
    }

    private fun stopRecording() {
        var ok = recording
        recording = false
        try {
            recorder?.stop()
        } catch (e: Exception) {
            ok = false
            message = "วิดีโอสั้นเกินไปหรือบันทึกไม่สำเร็จ"
        }
        val name = fileName
        release(!ok)
        if (ok) message = "บันทึกแล้ว: Movies/CrosshairHud/$name"
    }

    private fun release(delete: Boolean) {
        try { recorder?.release() } catch (e: Exception) { }
        recorder = null
        try { display?.release() } catch (e: Exception) { }
        display = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        try { pfd?.close() } catch (e: Exception) { }
        pfd = null
        val uri = outUri
        if (uri != null) {
            try {
                if (delete) {
                    contentResolver.delete(uri, null, null)
                } else if (Build.VERSION.SDK_INT >= 29) {
                    val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    contentResolver.update(uri, v, null, null)
                }
            } catch (e: Exception) { }
        }
        outUri = null
        val f = outFile
        if (f != null && delete) f.delete()
        outFile = null
    }

    @Suppress("DEPRECATION")
    private fun startAsForeground(mic: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("rec", "Screen recording", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = Notification.Builder(this, "rec")
            .setContentTitle("กำลังอัดหน้าจอ")
            .setContentText("แตะ 'หยุดอัด' เพื่อบันทึกวิดีโอ")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_media_pause, "หยุดอัด", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (mic && Build.VERSION.SDK_INT >= 30) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(2, n, type)
        } else {
            startForeground(2, n)
        }
    }
}
