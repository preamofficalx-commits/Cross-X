package com.example.crosshair

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.net.TrafficStats
import android.os.Environment
import android.os.Process
import android.os.SystemClock
import android.os.StatFs
import java.io.File

data class BatteryState(val percent: Int, val tempC: Float, val charging: Boolean)

data class MemState(val usedMb: Long, val totalMb: Long) {
    val pct: Int get() = if (totalMb > 0) (usedMb * 100 / totalMb).toInt() else 0
}

object Stats {

    fun battery(ctx: Context): BatteryState {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return BatteryState(-1, 0f, false)
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        return BatteryState(pct, temp, charging)
    }

    // ---------- CPU ----------

    private var procOk = true
    private var lastTotal = 0L
    private var lastIdle = 0L

    /** อ่านโหลด CPU จาก /proc/stat (ใช้ได้เฉพาะบางเครื่อง) ถ้าอ่านไม่ได้จะใช้ความเร็วคล็อกแทน */
    private var cpuCache: Int? = null
    private var cpuCacheT = 0L

    @Synchronized
    fun cpuPercent(): Int? {
        val now = SystemClock.elapsedRealtime()
        if (cpuCacheT != 0L && now - cpuCacheT < 700) return cpuCache
        val a = procStatPercent()
        val r = a ?: cpuFreqPercent()
        cpuCache = r
        cpuCacheT = now
        return r
    }

    private fun procStatPercent(): Int? {
        if (!procOk) return null
        val line: String? = try {
            File("/proc/stat").bufferedReader().use { it.readLine() }
        } catch (e: Exception) {
            null
        }
        if (line == null) {
            procOk = false
            return null
        }
        val p = line.trim().split(Regex("\\s+"))
        if (p.size < 8 || p[0] != "cpu") {
            procOk = false
            return null
        }
        val v = p.subList(1, 8).map { it.toLongOrNull() ?: 0L }
        val idle = v[3] + v[4]
        val total = v.sum()
        val first = lastTotal == 0L
        val dTotal = total - lastTotal
        val dIdle = idle - lastIdle
        lastTotal = total
        lastIdle = idle
        if (first) return 0
        if (dTotal <= 0) return null
        return ((dTotal - dIdle) * 100 / dTotal).toInt().coerceIn(0, 100)
    }

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().toLong()
    } catch (e: Exception) {
        null
    }

    private fun cpuFreqPercent(): Int? {
        var sum = 0.0
        var n = 0
        val cores = Runtime.getRuntime().availableProcessors()
        for (c in 0 until cores) {
            val base = "/sys/devices/system/cpu/cpu$c/cpufreq/"
            val cur = readLong(base + "scaling_cur_freq") ?: continue
            val max = readLong(base + "cpuinfo_max_freq") ?: readLong(base + "scaling_max_freq") ?: continue
            if (max <= 0) continue
            sum += cur.toDouble() / max
            n++
        }
        if (n == 0) return null
        return (sum / n * 100).toInt().coerceIn(0, 100)
    }

    // ---------- GPU ----------

    fun gpuPercent(): Int? {
        val paths = listOf(
            "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage", // Qualcomm Adreno
            "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load",
            "/sys/kernel/gpu/gpu_busy",
            "/sys/devices/platform/13000000.mali/utilization", // Mali (บางรุ่น)
            "/sys/class/misc/mali0/device/utilisation",
            "/sys/module/ged/parameters/gpu_loading" // MediaTek
        )
        for (path in paths) {
            try {
                val n = Regex("\\d+").find(File(path).readText())?.value?.toInt()
                if (n != null) return n.coerceIn(0, 100)
            } catch (e: Exception) {
            }
        }
        return null
    }

    // ---------- NET ----------

    private var lastRx = -1L
    private var lastTx = -1L
    private var lastNetT = 0L

    /** ความเร็วเน็ตรวมทั้งเครื่อง (ไบต์/วินาที): คู่ (ดาวน์โหลด, อัปโหลด) หรือ null ถ้าเครื่องไม่รองรับ */
    @Synchronized
    fun netSpeed(): Pair<Long, Long>? {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx < 0 || tx < 0) return null
        val now = SystemClock.elapsedRealtime()
        val res = if (lastRx >= 0 && now > lastNetT) {
            val dt = now - lastNetT
            Pair((rx - lastRx) * 1000 / dt, (tx - lastTx) * 1000 / dt)
        } else {
            Pair(0L, 0L)
        }
        lastRx = rx
        lastTx = tx
        lastNetT = now
        return res
    }

    fun formatSpeed(bytesPerSec: Long): String {
        val b = if (bytesPerSec < 0) 0L else bytesPerSec
        return if (b >= 1024L * 1024L) {
            String.format(java.util.Locale.US, "%.1fM", b / 1048576.0)
        } else {
            "${b / 1024}K"
        }
    }

    // ---------- แอปที่ใช้อยู่ (ต้องเปิด Usage Access) ----------

    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private var fgPkg: String? = null
    private var fgScanT = 0L

    @Synchronized
    @Suppress("DEPRECATION")
    fun foregroundPackage(ctx: Context): String? {
        if (!hasUsageAccess(ctx)) return null
        return try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (fgScanT == 0L) now - 2 * 3600_000L else fgScanT - 1500L
            val events = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                when (e.eventType) {
                    UsageEvents.Event.MOVE_TO_FOREGROUND -> fgPkg = e.packageName
                    UsageEvents.Event.MOVE_TO_BACKGROUND -> if (fgPkg == e.packageName) fgPkg = null
                }
            }
            fgScanT = now
            fgPkg
        } catch (ex: Exception) {
            null
        }
    }

    private val labelCache = HashMap<String, String>()

    @Synchronized
    fun appLabel(ctx: Context, pkg: String): String {
        labelCache[pkg]?.let { return it }
        val label = try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        labelCache[pkg] = label
        return label
    }

    // ---------- RAM / DISK ----------

    fun memory(ctx: Context): MemState {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / (1024 * 1024)
        val used = (mi.totalMem - mi.availMem) / (1024 * 1024)
        return MemState(used, total)
    }

    fun diskPercent(): Int {
        return try {
            val s = StatFs(Environment.getDataDirectory().path)
            val total = s.totalBytes
            val free = s.availableBytes
            if (total > 0) ((total - free) * 100 / total).toInt() else 0
        } catch (e: Exception) {
            0
        }
    }
}
