package com.example.crosshair

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.io.File

data class BatteryState(val percent: Int, val tempC: Float, val charging: Boolean)

data class MemState(val usedMb: Long, val totalMb: Long) {
    val pct: Int get() = if (totalMb > 0) (usedMb * 100 / totalMb).toInt() else 0
}

object Stats {

    fun battery(ctx: Context): BatteryState {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return BatteryState(-1, 0f, false)
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        return BatteryState(pct, temp, charging)
    }

    // ---------- CPU ----------

    private var procOk = true
    private var lastTotal = 0L
    private var lastIdle = 0L

    /** อ่านโหลด CPU จาก /proc/stat (ใช้ได้เฉพาะบางเครื่อง) ถ้าอ่านไม่ได้จะใช้ความเร็วคล็อกแทน */
    @Synchronized
    fun cpuPercent(): Int? {
        val a = procStatPercent()
        if (a != null) return a
        return cpuFreqPercent()
    }

    private fun procStatPercent(): Int? {
        if (!procOk) return null
        val line: String? = try {
            File("/proc/stat").bufferedReader().use { it.readLine() }
        } catch (e: Exception) {
            null
        }
        if (line == null) {
            procOk = false
            return null
        }
        val p = line.trim().split(Regex("\\s+"))
        if (p.size < 8 || p[0] != "cpu") {
            procOk = false
            return null
        }
        val v = p.subList(1, 8).map { it.toLongOrNull() ?: 0L }
        val idle = v[3] + v[4]
        val total = v.sum()
        val first = lastTotal == 0L
        val dTotal = total - lastTotal
        val dIdle = idle - lastIdle
        lastTotal = total
        lastIdle = idle
        if (first) return 0
        if (dTotal <= 0) return null
        return ((dTotal - dIdle) * 100 / dTotal).toInt().coerceIn(0, 100)
    }

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().toLong()
    } catch (e: Exception) {
        null
    }

    private fun cpuFreqPercent(): Int? {
        var sum = 0.0
        var n = 0
        val cores = Runtime.getRuntime().availableProcessors()
        for (c in 0 until cores) {
            val base = "/sys/devices/system/cpu/cpu$c/cpufreq/"
            val cur = readLong(base + "scaling_cur_freq") ?: continue
            val max = readLong(base + "cpuinfo_max_freq") ?: readLong(base + "scaling_max_freq") ?: continue
            if (max <= 0) continue
            sum += cur.toDouble() / max
            n++
        }
        if (n == 0) return null
        return (sum / n * 100).toInt().coerceIn(0, 100)
    }

    // ---------- GPU ----------

    fun gpuPercent(): Int? {
        val paths = listOf(
            "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage", // Qualcomm Adreno
            "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load",
            "/sys/kernel/gpu/gpu_busy",
            "/sys/devices/platform/13000000.mali/utilization", // Mali (บางรุ่น)
            "/sys/class/misc/mali0/device/utilisation",
            "/sys/module/ged/parameters/gpu_loading" // MediaTek
        )
        for (path in paths) {
            try {
                val n = Regex("\\d+").find(File(path).readText())?.value?.toInt()
                if (n != null) return n.coerceIn(0, 100)
            } catch (e: Exception) {
            }
        }
        return null
    }

    // ---------- RAM / DISK ----------

    fun memory(ctx: Context): MemState {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / (1024 * 1024)
        val used = (mi.totalMem - mi.availMem) / (1024 * 1024)
        return MemState(used, total)
    }

    fun diskPercent(): Int {
        return try {
            val s = StatFs(Environment.getDataDirectory().path)
            val total = s.totalBytes
            val free = s.availableBytes
            if (total > 0) ((total - free) * 100 / total).toInt() else 0
        } catch (e: Exception) {
            0
        }
    }
}
