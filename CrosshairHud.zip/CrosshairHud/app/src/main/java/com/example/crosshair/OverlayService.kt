package com.example.crosshair

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/** เป้าเล็ง + HUD (แบต / แอปที่ใช้ / CPU / GPU / RAM / เน็ต / เวลา) + แผงปุ่มลอย */
class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.example.crosshair.STOP"
    }

    private lateinit var wm: WindowManager
    private var crosshair: CrosshairView? = null
    private var crosshairParams: WindowManager.LayoutParams? = null
    private var panel: TextView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var controls: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("reticle", MODE_PRIVATE) }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        crosshair?.reload()
        applyOffset()
        applyVisibility()
        applyHudStyle()
        refreshHud()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            refreshHud()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addCrosshair()
        addPanel()
        addControls()
        applyVisibility()
        applyHudStyle()
        running = true
        refreshHud()
        handler.postDelayed(tick, 1000)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        runCatching { prefs.unregisterOnSharedPreferenceChangeListener(prefListener) }
        crosshair?.let { v -> runCatching { wm.removeView(v) } }
        panel?.let { v -> runCatching { wm.removeView(v) } }
        controls?.let { v -> runCatching { wm.removeView(v) } }
        super.onDestroy()
    }

    // ---------- Overlay windows ----------

    private fun overlayParams(touchable: Boolean, gravity: Int): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }
    }

    private fun addCrosshair() {
        val v = CrosshairView(this)
        crosshair = v
        val lp = overlayParams(false, Gravity.CENTER)
        lp.x = (prefs.getInt("offx", 0) * resources.displayMetrics.density).toInt()
        lp.y = (prefs.getInt("offy", 0) * resources.displayMetrics.density).toInt()
        crosshairParams = lp
        wm.addView(v, lp)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    private fun applyOffset() {
        val v = crosshair ?: return
        val lp = crosshairParams ?: return
        val d = resources.displayMetrics.density
        lp.x = (prefs.getInt("offx", 0) * d).toInt()
        lp.y = (prefs.getInt("offy", 0) * d).toInt()
        runCatching { wm.updateViewLayout(v, lp) }
    }

    private fun applyVisibility() {
        crosshair?.visibility = if (prefs.getBoolean("cross_on", true)) View.VISIBLE else View.GONE
        controls?.visibility = if (prefs.getBoolean("move_on", true)) View.VISIBLE else View.GONE
    }

    // ---------- HUD ----------

    private fun addPanel() {
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setLineSpacing(0f, 1.1f)
            setPadding(dp(10), dp(7), dp(10), dp(7))
        }
        panel = tv
        val lp = overlayParams(false, Gravity.TOP or Gravity.START)
        lp.x = dp(8)
        lp.y = dp(24)
        panelParams = lp
        wm.addView(tv, lp)
    }

    private fun applyHudStyle() {
        val p = panel ?: return
        val lp = panelParams ?: return
        val a = prefs.getInt("hud_alpha", 85).coerceIn(20, 100)
        p.background = rounded(Color.argb(a * 255 / 100, 8, 12, 24), dp(12).toFloat(), Theme.STROKE, dp(1))
        val pos = prefs.getInt("hud_pos", 0)
        val side = when (pos) {
            0 -> Gravity.START
            1 -> Gravity.CENTER_HORIZONTAL
            else -> Gravity.END
        }
        lp.gravity = Gravity.TOP or side
        lp.x = if (pos == 1) 0 else dp(8)
        runCatching { wm.updateViewLayout(p, lp) }
    }

    private fun refreshHud() {
        val p = panel ?: return
        if (!prefs.getBoolean("hud_on", true)) {
            p.visibility = View.GONE
            return
        }
        val t = buildHud()
        p.text = t
        p.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun buildHud(): CharSequence {
        val sb = SpannableStringBuilder()
        var first = true

        fun put(text: String, color: Int) {
            val s = sb.length
            sb.append(text)
            sb.setSpan(ForegroundColorSpan(color), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        fun newLine() {
            if (!first) sb.append('\n')
            first = false
        }

        fun level(pct: Int?): Int = when {
            pct == null -> Theme.MUTED
            pct >= 85 -> Theme.DANGER
            pct >= 65 -> Theme.WARN
            else -> Color.WHITE
        }

        if (prefs.getBoolean("hud_batt", true)) {
            newLine()
            val b = Stats.battery(this)
            val pct: Int? = if (b.percent >= 0) b.percent else null
            put("BAT ", Theme.MUTED)
            val battColor = if (pct != null && pct <= 20 && !b.charging) Theme.DANGER else Color.WHITE
            put(if (pct != null) "$pct%" else "N/A", battColor)
            if (b.charging) put("⚡", Theme.ACCENT)
            val tempColor = if (b.tempC >= 42f) Theme.DANGER else if (b.tempC >= 38f) Theme.WARN else Theme.MUTED
            put("  " + String.format(Locale.US, "%.1f°C", b.tempC), tempColor)
        }

        val showCpu = prefs.getBoolean("hud_cpu", true)
        val showGpu = prefs.getBoolean("hud_gpu", true)
        if (showCpu || showGpu) {
            newLine()
            if (showCpu) {
                val v = Stats.cpuPercent()
                put("CPU ", Theme.MUTED)
                put(if (v != null) "$v%" else "N/A", level(v))
            }
            if (showCpu && showGpu) put("  ", Theme.MUTED)
            if (showGpu) {
                val v = Stats.gpuPercent()
                put("GPU ", Theme.MUTED)
                put(if (v != null) "$v%" else "N/A", level(v))
            }
        }

        if (prefs.getBoolean("hud_ram", true)) {
            newLine()
            val m = Stats.memory(this)
            put("RAM ", Theme.MUTED)
            put("${m.pct}%", level(m.pct))
        }

        if (prefs.getBoolean("hud_net", false)) {
            newLine()
            val n = Stats.netSpeed()
            put("NET ", Theme.MUTED)
            if (n == null) {
                put("N/A", Theme.MUTED)
            } else {
                put("↓" + Stats.formatSpeed(n.first), Theme.ACCENT)
                put(" ↑" + Stats.formatSpeed(n.second), Theme.ACCENT2)
            }
        }

        if (prefs.getBoolean("hud_app", true)) {
            newLine()
            put("APP ", Theme.MUTED)
            if (!Stats.hasUsageAccess(this)) {
                put("ต้องเปิด Usage Access", Theme.WARN)
            } else {
                val pkg = Stats.foregroundPackage(this)
                val name = when {
                    pkg == null -> "—"
                    pkg == packageName -> "Reticle"
                    else -> Stats.appLabel(this, pkg).take(22)
                }
                put(name, Color.WHITE)
            }
        }

        if (prefs.getBoolean("hud_clock", false)) {
            newLine()
            val t = java.text.SimpleDateFormat("HH:mm", Locale.US).format(java.util.Date())
            put("TIME ", Theme.MUTED)
            put(t, Color.WHITE)
        }
        return sb
    }

    // ---------- แผงปุ่มลอย ----------

    private fun nudge(dx: Int, dy: Int) {
        val st = prefs.getInt("step", 1)
        val x = (prefs.getInt("offx", 0) + dx * st).coerceIn(-300, 300)
        val y = (prefs.getInt("offy", 0) + dy * st).coerceIn(-300, 300)
        prefs.edit().putInt("offx", x).putInt("offy", y).apply()
    }

    private fun resetOffset() {
        prefs.edit().putInt("offx", 0).putInt("offy", 0).apply()
    }

    private fun addControls() {
        val size = dp(46)
        val margin = dp(2)
        val padW = (size + 2 * margin) * 3
        val boxW = padW + dp(8)
        val btnFill = Color.parseColor("#E6141E34")

        fun btn(label: String, onTick: () -> Unit): TextView {
            var repeater: Runnable? = null
            return TextView(this).apply {
                text = label
                textSize = 20f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = rounded(btnFill, dp(14).toFloat(), Theme.STROKE, dp(1))
                layoutParams = LinearLayout.LayoutParams(size, size).apply {
                    setMargins(margin, margin, margin, margin)
                }
                setOnTouchListener { _, ev ->
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> {
                            onTick()
                            val r = object : Runnable {
                                override fun run() {
                                    onTick()
                                    handler.postDelayed(this, 50)
                                }
                            }
                            repeater = r
                            handler.postDelayed(r, 400)
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            repeater?.let { handler.removeCallbacks(it) }
                            repeater = null
                        }
                    }
                    true
                }
            }
        }

        fun tap(label: String, onClick: (TextView) -> Unit): TextView {
            val tv = TextView(this)
            tv.text = label
            tv.textSize = 13f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setTextColor(Theme.ACCENT)
            tv.gravity = Gravity.CENTER
            tv.background = rounded(btnFill, dp(12).toFloat(), Theme.STROKE, dp(1))
            tv.layoutParams = LinearLayout.LayoutParams(size, dp(36)).apply {
                setMargins(margin, margin, margin, margin)
            }
            tv.setOnClickListener { onClick(tv) }
            return tv
        }

        fun row(vararg views: View): LinearLayout {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_HORIZONTAL
            r.layoutParams = LinearLayout.LayoutParams(padW, LinearLayout.LayoutParams.WRAP_CONTENT)
            views.forEach { r.addView(it) }
            return r
        }

        fun spacer(): View {
            val v = View(this)
            v.layoutParams = LinearLayout.LayoutParams(size + 2 * margin, size)
            return v
        }

        val eyeBtn = tap("◎") { _ ->
            prefs.edit().putBoolean("cross_on", !prefs.getBoolean("cross_on", true)).apply()
        }
        val stepBtn = tap("×" + prefs.getInt("step", 1)) { tv ->
            val next = when (prefs.getInt("step", 1)) {
                1 -> 5
                5 -> 10
                else -> 1
            }
            prefs.edit().putInt("step", next).apply()
            tv.text = "×$next"
        }
        val hudBtn = tap("HUD") { _ ->
            prefs.edit().putBoolean("hud_on", !prefs.getBoolean("hud_on", true)).apply()
        }

        val pad = LinearLayout(this)
        pad.orientation = LinearLayout.VERTICAL
        pad.gravity = Gravity.CENTER_HORIZONTAL
        pad.addView(row(spacer(), btn("▲") { nudge(0, -1) }, spacer()))
        pad.addView(row(btn("◀") { nudge(-1, 0) }, btn("●") { resetOffset() }, btn("▶") { nudge(1, 0) }))
        pad.addView(row(spacer(), btn("▼") { nudge(0, 1) }, spacer()))
        pad.addView(row(eyeBtn, stepBtn, hudBtn))

        val lp = overlayParams(true, Gravity.TOP or Gravity.END)
        lp.width = boxW
        lp.x = dp(8)
        lp.y = dp(60)

        val toggle = ImageView(this).apply {
            setImageResource(R.drawable.floating_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#D6D2D1"))
                setStroke(dp(2), Theme.ACCENT)
            }
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX
                        downY = ev.rawY
                        startX = lp.x
                        startY = lp.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.rawX - downX
                        val dy = ev.rawY - downY
                        if (moved || Math.abs(dx) > dp(10) || Math.abs(dy) > dp(10)) {
                            moved = true
                            // gravity = TOP|END ดังนั้นแกน x วัดจากขอบขวา
                            lp.x = startX - dx.toInt()
                            lp.y = startY + dy.toInt()
                            controls?.let { v -> runCatching { wm.updateViewLayout(v, lp) } }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            pad.visibility =
                                if (pad.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                            controls?.let { v -> runCatching { wm.updateViewLayout(v, lp) } }
                        }
                    }
                }
                true
            }
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Color.parseColor("#A60A0F1C"), dp(18).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(4), dp(2), dp(4), dp(6))
            addView(toggle)
            addView(pad, LinearLayout.LayoutParams(padW, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        controls = box
        wm.addView(box, lp)
    }

    // ---------- Foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("reticle", "Reticle", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "หยุด",
            stop
        ).build()
        val n: Notification = Notification.Builder(this, "reticle")
            .setContentTitle("Reticle กำลังทำงาน")
            .setContentText("แตะเพื่อเปิดแอป")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }
}
