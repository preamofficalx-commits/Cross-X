package com.example.crosshair

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/** วางเป้าเล็ง + HUD (แบต / CPU / GPU) + ปุ่มเลื่อนเป้า ทับหน้าจอ */
class OverlayService : Service() {

    companion object {
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private var crosshair: CrosshairView? = null
    private var crosshairParams: WindowManager.LayoutParams? = null
    private var panel: TextView? = null
    private var controls: View? = null
    private var recChip: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("crosshair", MODE_PRIVATE) }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        crosshair?.reload()
        applyOffset()
        applyVisibility()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            panel?.text = buildStats()
            recChip?.visibility = if (RecorderService.recording) View.VISIBLE else View.GONE
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addCrosshair()
        addPanel()
        addControls()
        applyVisibility()
        running = true
        handler.post(tick)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        runCatching { prefs.unregisterOnSharedPreferenceChangeListener(prefListener) }
        crosshair?.let { v -> runCatching { wm.removeView(v) } }
        panel?.let { v -> runCatching { wm.removeView(v) } }
        controls?.let { v -> runCatching { wm.removeView(v) } }
        super.onDestroy()
    }

    // ---------- Overlay views ----------

    private fun overlayParams(touchable: Boolean, gravity: Int): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }
    }

    private fun addCrosshair() {
        val v = CrosshairView(this)
        crosshair = v
        val lp = overlayParams(false, Gravity.CENTER)
        lp.x = (prefs.getInt("offx", 0) * resources.displayMetrics.density).toInt()
        lp.y = (prefs.getInt("offy", 0) * resources.displayMetrics.density).toInt()
        crosshairParams = lp
        wm.addView(v, lp)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    private fun applyOffset() {
        val v = crosshair ?: return
        val lp = crosshairParams ?: return
        val d = resources.displayMetrics.density
        lp.x = (prefs.getInt("offx", 0) * d).toInt()
        lp.y = (prefs.getInt("offy", 0) * d).toInt()
        runCatching { wm.updateViewLayout(v, lp) }
    }

    private fun applyVisibility() {
        panel?.visibility = if (prefs.getBoolean("hud_on", true)) View.VISIBLE else View.GONE
        controls?.visibility = if (prefs.getBoolean("move_on", true)) View.VISIBLE else View.GONE
    }

    private fun addPanel() {
        val tv = TextView(this).apply {
            setTextColor(Theme.ACCENT)
            background = rounded(Color.parseColor("#C20A0F1C"), dp(10).toFloat(), Theme.STROKE, dp(1))
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        panel = tv
        val lp = overlayParams(false, Gravity.TOP or Gravity.START)
        lp.x = dp(8)
        lp.y = dp(24)
        wm.addView(tv, lp)
    }

    // ---------- ปุ่มลอยสำหรับเลื่อนเป้า ----------

    private fun nudge(dx: Int, dy: Int) {
        val x = (prefs.getInt("offx", 0) + dx).coerceIn(-300, 300)
        val y = (prefs.getInt("offy", 0) + dy).coerceIn(-300, 300)
        prefs.edit().putInt("offx", x).putInt("offy", y).apply()
    }

    private fun resetOffset() {
        prefs.edit().putInt("offx", 0).putInt("offy", 0).apply()
    }

    private fun addControls() {
        val size = dp(46)
        val margin = dp(2)

        fun btn(label: String, onTick: () -> Unit): TextView {
            var repeater: Runnable? = null
            return TextView(this).apply {
                text = label
                textSize = 20f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = rounded(Color.parseColor("#E6121A2C"), dp(12).toFloat(), Theme.STROKE, dp(1))
                layoutParams = LinearLayout.LayoutParams(size, size).apply {
                    setMargins(margin, margin, margin, margin)
                }
                setOnTouchListener { _, ev ->
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> {
                            onTick()
                            val r = object : Runnable {
                                override fun run() {
                                    onTick()
                                    handler.postDelayed(this, 50)
                                }
                            }
                            repeater = r
                            handler.postDelayed(r, 400)
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            repeater?.let { handler.removeCallbacks(it) }
                            repeater = null
                        }
                    }
                    true
                }
            }
        }

        fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            views.forEach { addView(it) }
        }

        fun spacer(): View = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(size + 2 * margin, size)
        }

        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(row(spacer(), btn("▲") { nudge(0, -1) }, spacer()))
            addView(row(btn("◀") { nudge(-1, 0) }, btn("●") { resetOffset() }, btn("▶") { nudge(1, 0) }))
            addView(row(spacer(), btn("▼") { nudge(0, 1) }, spacer()))
        }

        val lp = overlayParams(true, Gravity.TOP or Gravity.END)
        lp.x = dp(8)
        lp.y = dp(60)

        val toggle = ImageView(this).apply {
            setImageResource(R.drawable.floating_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#D6D2D1"))
                setStroke(dp(2), Theme.ACCENT)
            }
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX
                        downY = ev.rawY
                        startX = lp.x
                        startY = lp.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.rawX - downX
                        val dy = ev.rawY - downY
                        if (moved || Math.abs(dx) > dp(10) || Math.abs(dy) > dp(10)) {
                            moved = true
                            // gravity = TOP|END ดังนั้นแกน x วัดจากขอบขวา
                            lp.x = startX - dx.toInt()
                            lp.y = startY + dy.toInt()
                            controls?.let { v -> runCatching { wm.updateViewLayout(v, lp) } }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            pad.visibility =
                                if (pad.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                            controls?.let { v -> runCatching { wm.updateViewLayout(v, lp) } }
                        }
                    }
                }
                true
            }
        }

        val chip = TextView(this).apply {
            text = "■ หยุดอัดหน้าจอ"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Theme.DANGER, dp(10).toFloat())
            setPadding(dp(8), dp(8), dp(8), dp(8))
            visibility = View.GONE
            setOnClickListener {
                startService(Intent(this@OverlayService, RecorderService::class.java)
                    .setAction(RecorderService.ACTION_STOP))
            }
        }
        recChip = chip

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Color.parseColor("#990A0F1C"), dp(14).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(4), dp(2), dp(4), dp(6))
            addView(toggle)
            addView(pad)
            addView(chip)
        }
        controls = box
        wm.addView(box, lp)
    }

    // ---------- Stats ----------

    private fun buildStats(): String {
        val b = Stats.battery(this)
        val cpu = Stats.cpuPercent()
        val gpu = Stats.gpuPercent()
        val batt = if (b.percent >= 0) "${b.percent}%" else "N/A"
        val chg = if (b.charging) "⚡" else ""
        val temp = String.format(Locale.US, "%.1f", b.tempC)
        val sb = StringBuilder()
        sb.append("BATT ").append(batt).append(chg).append("  ").append(temp).append("°C\n")
        sb.append("CPU  ").append(cpu?.let { "$it%" } ?: "N/A").append('\n')
        sb.append("GPU  ").append(gpu?.let { "$it%" } ?: "N/A")
        return sb.toString()
    }

    // ---------- Foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("hud", "Maps", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, "hud")
            .setContentTitle("Maps กำลังทำงาน")
            .setContentText("ปิดได้จากในแอป")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }
}
