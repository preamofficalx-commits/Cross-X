package com.example.crosshair

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.io.File

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var crosshair: View? = null
    private var panel: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private var frames = 0
    private var fps = 0
    private var running = false
    private var lastPkg = ""

    private val prefs by lazy { getSharedPreferences("crosshair", MODE_PRIVATE) }
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        (crosshair as? CrosshairView)?.reload()
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            fps = frames
            frames = 0
            panel?.text = buildStats()
            if (running) handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addCrosshair()
        addPanel()
        running = true
        Choreographer.getInstance().postFrameCallback(frameCb)
        handler.post(tick)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        runCatching { prefs.unregisterOnSharedPreferenceChangeListener(prefListener) }
        Choreographer.getInstance().removeFrameCallback(frameCb)
        crosshair?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    // ---------- Overlay views ----------

    private fun overlayParams(w: Int, h: Int, gravity: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { this.gravity = gravity }

    private fun addCrosshair() {
        val v = CrosshairView(this)
        crosshair = v
        wm.addView(v, overlayParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    private fun addPanel() {
        val dp = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setTextColor(Color.parseColor("#7CFC00"))
            setBackgroundColor(Color.parseColor("#99000000"))
            typeface = Typeface.MONOSPACE
            textSize = 11f
            val p = (6 * dp).toInt()
            setPadding(p, p, p, p)
        }
        panel = tv
        wm.addView(tv, overlayParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
    }

    // ---------- Stats ----------

    private fun buildStats(): String {
        val sb = StringBuilder()
        sb.append("FPS  : ").append(fps).append('\n')
        sb.append("GPU  : ").append(gpuLoad()).append('\n')
        sb.append("BATT : ").append(batteryInfo()).append('\n')
        sb.append("RAM  : ").append(ramInfo()).append('\n')
        sb.append("APP  : ").append(foregroundApp())
        return sb.toString()
    }

    private fun gpuLoad(): String {
        val paths = listOf(
            "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage", // Qualcomm Adreno
            "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load",
            "/sys/kernel/gpu/gpu_busy"                        // บางรุ่นของ Samsung/Mali
        )
        for (p in paths) {
            try {
                val n = Regex("\\d+").find(File(p).readText())?.value
                if (n != null) return "$n%"
            } catch (_: Exception) { }
        }
        return "N/A"
    }

    private fun batteryInfo(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return "N/A"
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0) level * 100 / scale else -1
        return "$pct% ${"%.1f".format(temp)}°C" + if (charging) " ⚡" else ""
    }

    private fun ramInfo(): String {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val usedMb = (mi.totalMem - mi.availMem) / (1024 * 1024)
        val totalMb = mi.totalMem / (1024 * 1024)
        return "$usedMb/$totalMb MB"
    }

    @Suppress("DEPRECATION")
    private fun foregroundApp(): String {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 60_000, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastPkg = e.packageName
        }
        if (lastPkg.isEmpty()) return "ไม่มีข้อมูล (เปิด Usage Access?)"
        return try {
            val info = packageManager.getApplicationInfo(lastPkg, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            lastPkg
        }
    }

    // ---------- Foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("hud", "Crosshair HUD", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, "hud")
            .setContentTitle("Crosshair HUD กำลังทำงาน")
            .setContentText("ปิดได้จากในแอป")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }
}

/** เป้ากลางจอ: ขนาด ความหนา และสี ปรับได้จากหน้าแอป (อ่านค่าจาก SharedPreferences) */
class CrosshairView(context: Context) : View(context) {
    private val dp = resources.displayMetrics.density
    private val prefs = context.getSharedPreferences("crosshair", Context.MODE_PRIVATE)

    private var sizePx = (48 * dp).toInt()
    private var lenPx = 20 * dp
    private var gapPx = 5 * dp

    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    init { reload() }

    fun reload() {
        val sizeDp = prefs.getInt("size", 48)
        val thickDp = prefs.getInt("thick", 2)
        val hue = prefs.getInt("hue", 0)
        val sat = prefs.getInt("sat", 100)
        val color = Color.HSVToColor(floatArrayOf(hue.toFloat(), sat / 100f, 1f))

        sizePx = (sizeDp * dp).toInt()
        lenPx = (sizeDp / 2f - 4f) * dp
        gapPx = maxOf(3f, sizeDp * 0.1f) * dp
        line.color = color
        line.strokeWidth = thickDp * dp
        outline.strokeWidth = (thickDp + 2) * dp
        dot.color = color
        requestLayout()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(sizePx, sizePx)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        for (p in listOf(outline, line)) {
            c.drawLine(cx - lenPx, cy, cx - gapPx, cy, p)
            c.drawLine(cx + gapPx, cy, cx + lenPx, cy, p)
            c.drawLine(cx, cy - lenPx, cx, cy - gapPx, p)
            c.drawLine(cx, cy + gapPx, cx, cy + lenPx, p)
        }
        c.drawCircle(cx, cy, maxOf(1.5f, line.strokeWidth / dp * 0.75f) * dp, dot)
    }
}
