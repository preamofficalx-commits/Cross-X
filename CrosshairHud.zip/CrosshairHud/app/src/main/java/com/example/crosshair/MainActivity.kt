package com.example.crosshair

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_CAPTURE = 100
private const val REQ_NOTIF = 1
private const val REQ_MIC = 2

class MainActivity : Activity() {

    private class Cell(val root: View, val value: TextView, val fill: View, val rest: View)

    private val prefs by lazy { getSharedPreferences("crosshair", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var content: FrameLayout
    private val pages = ArrayList<View>()
    private val navItems = ArrayList<TextView>()

    // header
    private lateinit var statusChip: TextView

    // home
    private lateinit var cellBatt: Cell
    private lateinit var cellCpu: Cell
    private lateinit var cellGpu: Cell
    private lateinit var cellRam: Cell
    private lateinit var cellTemp: Cell
    private lateinit var cellDisk: Cell
    private lateinit var hint: TextView
    private lateinit var startBtn: TextView
    private lateinit var permBtn: TextView

    // crosshair tab
    private lateinit var preview: CrosshairView
    private val resetters = ArrayList<() -> Unit>()

    // record tab
    private lateinit var recBtn: TextView
    private lateinit var recTimer: TextView
    private lateinit var recStatus: TextView
    private lateinit var micSwitch: Switch

    private val ticker = object : Runnable {
        override fun run() {
            refreshStats()
            refreshOverlayUi()
            refreshRecordUi()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Theme.BG
        window.navigationBarColor = Theme.BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Theme.BG)
        }
        root.addView(buildHeader())

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        pages.add(scroll(buildHome()))
        pages.add(scroll(buildCrosshairTab()))
        pages.add(scroll(buildRecordTab()))
        pages.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }

        root.addView(buildNav())
        setContentView(root)
        selectTab(0)
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    // ================= helpers =================

    private fun label(s: String, sizeSp: Float, color: Int = Theme.TEXT, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = sizeSp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Theme.CARD, dp(22).toFloat(), Theme.STROKE, dp(1))
        setPadding(dp(18), dp(18), dp(18), dp(18))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(16), dp(8), dp(16), dp(8))
        }
    }

    private fun scroll(v: View): View = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        addView(v)
    }

    private fun bigButton(onClick: () -> Unit): TextView = TextView(this).apply {
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setOnClickListener { onClick() }
    }

    private fun styleBtn(tv: TextView, s: String, fill: Int, fg: Int) {
        tv.text = s
        tv.setTextColor(fg)
        tv.background = rounded(fill, dp(18).toFloat())
    }

    private fun tintSwitch(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(Theme.ACCENT, Theme.STROKE))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Theme.MUTED))
    }

    private fun switchRow(title: String, key: String, def: Boolean, onChange: (Boolean) -> Unit = {}): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, 0)
        }
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, def)
        tintSwitch(sw)
        sw.setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean(key, c).apply()
            onChange(c)
        }
        row.addView(label(title, 14f), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(sw)
        row.tag = sw
        return row
    }

    private fun segmented(options: List<String>, key: String, def: Int): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        val views = ArrayList<TextView>()
        fun restyle() {
            val sel = prefs.getInt(key, def)
            views.forEachIndexed { i, tv ->
                val on = i == sel
                tv.background = rounded(
                    if (on) Theme.ACCENT else Theme.BG, dp(12).toFloat(), Theme.STROKE, dp(1)
                )
                tv.setTextColor(if (on) Color.BLACK else Theme.MUTED)
            }
        }
        options.forEachIndexed { i, name ->
            val tv = TextView(this).apply {
                text = name
                textSize = 13f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), dp(10), dp(6), dp(10))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                    setMargins(dp(3), 0, dp(3), 0)
                }
                setOnClickListener {
                    prefs.edit().putInt(key, i).apply()
                    restyle()
                }
            }
            views.add(tv)
            row.addView(tv)
        }
        restyle()
        return row
    }

    // ================= header / nav =================

    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(6))
        }
        val title = SpannableStringBuilder("Crosshair")
        val start = title.length
        title.append("HUD")
        title.setSpan(
            ForegroundColorSpan(Theme.ACCENT), start, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        val t = TextView(this).apply {
            text = title
            textSize = 26f
            setTextColor(Theme.TEXT)
            typeface = Typeface.DEFAULT_BOLD
        }
        row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        statusChip = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        row.addView(statusChip)
        return row
    }

    private fun buildNav(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Theme.CARD, dp(28).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                setMargins(dp(16), dp(8), dp(16), dp(12))
            }
        }
        val names = listOf("🎯 หน้าหลัก", "🎛 ปรับเป้า", "🔴 อัดจอ")
        names.forEachIndexed { i, n ->
            val tv = TextView(this).apply {
                text = n
                textSize = 13f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(4), dp(12), dp(4), dp(12))
                setOnClickListener { selectTab(i) }
            }
            navItems.add(tv)
            bar.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return bar
    }

    private fun selectTab(i: Int) {
        pages.forEachIndexed { idx, v -> v.visibility = if (idx == i) View.VISIBLE else View.GONE }
        navItems.forEachIndexed { idx, tv ->
            val on = idx == i
            tv.setTextColor(if (on) Color.BLACK else Theme.MUTED)
            tv.background = if (on) rounded(Theme.ACCENT, dp(22).toFloat()) else null
        }
    }

    // ================= tab 1: home =================

    private fun makeCell(name: String): Cell {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(label(name, 11f, Theme.MUTED, true))
        val value = label("—", 18f, Theme.TEXT, true)
        root.addView(value)
        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 100f
            background = rounded(Theme.BG, dp(3).toFloat())
        }
        val fill = View(this).apply { background = rounded(Theme.ACCENT, dp(3).toFloat()) }
        val rest = View(this)
        track.addView(fill, LinearLayout.LayoutParams(0, dp(5), 0f))
        track.addView(rest, LinearLayout.LayoutParams(0, dp(5), 100f))
        root.addView(track, LinearLayout.LayoutParams(MATCH, dp(5)).apply { topMargin = dp(6) })
        return Cell(root, value, fill, rest)
    }

    private fun setCell(c: Cell, s: String, pct: Int?) {
        c.value.text = s
        val p = (pct ?: 0).coerceIn(0, 100)
        (c.fill.layoutParams as LinearLayout.LayoutParams).weight = p.toFloat()
        (c.rest.layoutParams as LinearLayout.LayoutParams).weight = (100 - p).toFloat()
        c.fill.requestLayout()
    }

    private fun gridRow(a: Cell, b: Cell, c: Cell): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }
        for (cell in listOf(a, b, c)) {
            r.addView(cell.root, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                setMargins(dp(6), dp(10), dp(6), dp(4))
            })
        }
        return r
    }

    private fun buildHome(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }

        val stats = card()
        stats.addView(label("Performance Stats", 18f, Theme.TEXT, true))
        stats.addView(label("ข้อมูลเครื่องแบบสด", 13f, Theme.MUTED))
        cellBatt = makeCell("BATT")
        cellCpu = makeCell("CPU")
        cellGpu = makeCell("GPU")
        cellRam = makeCell("RAM")
        cellTemp = makeCell("TEMP")
        cellDisk = makeCell("DISK")
        stats.addView(gridRow(cellBatt, cellCpu, cellGpu))
        stats.addView(gridRow(cellRam, cellTemp, cellDisk))
        hint = label("", 12f, Theme.MUTED)
        hint.setPadding(0, dp(8), 0, 0)
        hint.visibility = View.GONE
        stats.addView(hint)
        col.addView(stats)

        val act = card()
        act.addView(label("เป้าเล็ง + HUD", 18f, Theme.TEXT, true))
        act.addView(label("วางเป้าทับเกม พร้อมแสดงแบต / CPU / GPU", 13f, Theme.MUTED))
        startBtn = bigButton { toggleOverlay() }
        act.addView(startBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })
        permBtn = bigButton { openOverlaySettings() }
        permBtn.textSize = 14f
        styleBtn(permBtn, "⚠ ต้องอนุญาต 'แสดงทับแอปอื่น' ก่อน (แตะเพื่อตั้งค่า)", Theme.VIOLET, Color.WHITE)
        act.addView(permBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        act.addView(switchRow("แสดง HUD (แบต / CPU / GPU)", "hud_on", true))
        act.addView(switchRow("แสดงปุ่มเลื่อนเป้า", "move_on", true))
        col.addView(act)

        return col
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
        } else if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "ต้องอนุญาตแสดงทับแอปอื่นก่อน", Toast.LENGTH_LONG).show()
            openOverlaySettings()
        } else {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        handler.postDelayed({ refreshOverlayUi() }, 400)
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun refreshStats() {
        val b = Stats.battery(this)
        val battText = if (b.percent >= 0) "${b.percent}%" + (if (b.charging) "⚡" else "") else "—"
        setCell(cellBatt, battText, if (b.percent >= 0) b.percent else null)

        val cpu = Stats.cpuPercent()
        setCell(cellCpu, cpu?.let { "$it%" } ?: "N/A", cpu)

        val gpu = Stats.gpuPercent()
        setCell(cellGpu, gpu?.let { "$it%" } ?: "N/A", gpu)

        val m = Stats.memory(this)
        setCell(cellRam, "${m.pct}%", m.pct)

        setCell(cellTemp, String.format(Locale.US, "%.1f°C", b.tempC), (b.tempC * 100f / 60f).toInt())

        val d = Stats.diskPercent()
        setCell(cellDisk, "$d%", d)

        val notes = ArrayList<String>()
        if (gpu == null) notes.add("GPU: เครื่องนี้ไม่เปิดให้แอปอ่านค่า (ระบบ Android จำกัด)")
        if (cpu == null) notes.add("CPU: เครื่องนี้ไม่เปิดให้แอปอ่านค่า")
        hint.text = notes.joinToString("\n")
        hint.visibility = if (notes.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun refreshOverlayUi() {
        val on = OverlayService.running
        if (on) {
            styleBtn(startBtn, "■  หยุดเป้าเล็ง", Theme.DANGER, Color.WHITE)
        } else {
            styleBtn(startBtn, "▶  เริ่มเป้าเล็ง", Theme.ACCENT, Color.BLACK)
        }
        val recOn = RecorderService.recording
        val chipText = when {
            recOn -> "● กำลังอัด"
            on -> "● ทำงานอยู่"
            else -> "● ปิดอยู่"
        }
        val chipColor = when {
            recOn -> Theme.DANGER
            on -> Theme.ACCENT
            else -> Theme.MUTED
        }
        statusChip.text = chipText
        statusChip.setTextColor(chipColor)
        statusChip.background = rounded(Theme.CARD, dp(14).toFloat(), chipColor, dp(1))
        permBtn.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
    }

    // ================= tab 2: crosshair =================

    private fun slider(parent: LinearLayout, title: String, key: String, lo: Int, hi: Int, def: Int) {
        val value = prefs.getInt(key, def)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        val v = label("$value", 14f, Theme.ACCENT, true)
        head.addView(label(title, 14f), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(v)

        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = value - lo
        sb.progressTintList = ColorStateList.valueOf(Theme.ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(Theme.ACCENT)
        sb.progressBackgroundTintList = ColorStateList.valueOf(Theme.STROKE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + lo
                v.text = "$n"
                prefs.edit().putInt(key, n).apply()
                preview.reload()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        resetters.add { sb.progress = def - lo }
        parent.addView(head)
        parent.addView(sb)
    }

    private fun buildCrosshairTab(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }

        val pv = card()
        pv.addView(label("ตัวอย่างเป้า", 18f, Theme.TEXT, true))
        preview = CrosshairView(this)
        val box = FrameLayout(this).apply { background = rounded(Theme.BG, dp(16).toFloat()) }
        box.addView(
            preview,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER)
        )
        pv.addView(box, LinearLayout.LayoutParams(MATCH, dp(150)).apply { topMargin = dp(12) })
        col.addView(pv)

        val set = card()
        set.addView(label("ปรับแต่ง", 18f, Theme.TEXT, true))
        slider(set, "ขนาด", "size", 20, 160, 48)
        slider(set, "ความหนา", "thick", 1, 8, 2)
        slider(set, "สี (เฉดสี)", "hue", 0, 360, 0)
        slider(set, "ความเข้มสี (0 = ขาว)", "sat", 0, 100, 100)
        slider(set, "เลื่อนซ้าย (-) / ขวา (+)", "offx", -300, 300, 0)
        slider(set, "เลื่อนขึ้น (-) / ลง (+)", "offy", -300, 300, 0)
        val reset = bigButton { resetters.forEach { it() } }
        reset.textSize = 14f
        styleBtn(reset, "รีเซ็ตเป้า", Theme.STROKE, Color.WHITE)
        set.addView(reset, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) })
        col.addView(set)

        val tip = card()
        tip.addView(label("เคล็ดลับ", 15f, Theme.TEXT, true))
        tip.addView(
            label(
                "เริ่มเป้าแล้วเปิดเกม ใช้ปุ่มลูกศรที่ลอยอยู่มุมขวาบนขยับเป้าให้ตรงกลางจอ ลากข้อความ \"เลื่อนเป้า\" เพื่อย้ายแผงปุ่ม",
                13f, Theme.MUTED
            )
        )
        col.addView(tip)
        return col
    }

    // ================= tab 3: record =================

    private fun hasMic(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun buildRecordTab(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }

        val main = card()
        main.addView(label("อัดหน้าจอ", 18f, Theme.TEXT, true))
        main.addView(label("บันทึกเป็นวิดีโอ MP4 ลงแกลเลอรี", 13f, Theme.MUTED))
        recTimer = label("00:00", 44f, Theme.TEXT, true)
        recTimer.gravity = Gravity.CENTER
        main.addView(recTimer, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })
        recBtn = bigButton { toggleRecord() }
        main.addView(recBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        recStatus = label("", 13f, Theme.MUTED)
        recStatus.gravity = Gravity.CENTER
        main.addView(recStatus, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        col.addView(main)

        val opt = card()
        opt.addView(label("ตัวเลือกการอัด", 18f, Theme.TEXT, true))
        opt.addView(label("คุณภาพ", 14f, Theme.TEXT).apply { setPadding(0, dp(14), 0, 0) })
        opt.addView(segmented(listOf("720p", "1080p", "ต้นฉบับ"), "rec_q", 1))
        opt.addView(label("ทิศทางวิดีโอ", 14f, Theme.TEXT).apply { setPadding(0, dp(14), 0, 0) })
        opt.addView(segmented(listOf("ตามหน้าจอ", "แนวนอน", "แนวตั้ง"), "rec_o", 0))
        val micRow = switchRow("อัดเสียงจากไมค์", "rec_mic", false) { on ->
            if (on && !hasMic()) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            }
        }
        micSwitch = micRow.tag as Switch
        opt.addView(micRow)
        opt.addView(
            label(
                "ถ้าจะเล่นเกมแนวนอน ให้เลือก \"แนวนอน\" ก่อนเริ่มอัด ไฟล์จะอยู่ที่ Movies/CrosshairHud",
                12f, Theme.MUTED
            ).apply { setPadding(0, dp(12), 0, 0) }
        )
        col.addView(opt)
        return col
    }

    @Suppress("DEPRECATION")
    private fun toggleRecord() {
        if (RecorderService.recording) {
            startService(
                Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP)
            )
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, RecorderService::class.java)
                .setAction(RecorderService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
        } else {
            Toast.makeText(this, "ยกเลิกการอัดหน้าจอ", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (!ok) {
                prefs.edit().putBoolean("rec_mic", false).apply()
                micSwitch.isChecked = false
            }
        }
    }

    private fun refreshRecordUi() {
        val rec = RecorderService.recording
        if (rec) {
            styleBtn(recBtn, "■  หยุดอัด", Theme.VIOLET, Color.WHITE)
            val sec = ((SystemClock.elapsedRealtime() - RecorderService.startedAt) / 1000).toInt()
            recTimer.text = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
            recTimer.setTextColor(Theme.DANGER)
            recStatus.text = "กำลังอัดหน้าจอ… สลับไปเปิดเกมได้เลย"
        } else {
            styleBtn(recBtn, "●  เริ่มอัดหน้าจอ", Theme.DANGER, Color.WHITE)
            recTimer.text = "00:00"
            recTimer.setTextColor(Theme.TEXT)
            recStatus.text = RecorderService.message
        }
    }
}
