package com.example.crosshair

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Crosshair HUD"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "ทำตามลำดับ 1 → 2 → 3 (ข้อ 2 ใช้แสดงชื่อแอปที่กำลังเปิดอยู่)"
            setPadding(0, pad / 2, 0, pad / 2)
        })

        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        button("1. อนุญาตแสดงทับแอปอื่น") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. อนุญาตเข้าถึงข้อมูลการใช้งานแอป") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        button("3. เริ่มเป้ากลางจอ + HUD") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "ยังไม่ได้อนุญาตแสดงทับแอปอื่น (ข้อ 1)", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this, OverlayService::class.java))
            }
        }
        button("หยุด") {
            stopService(Intent(this, OverlayService::class.java))
        }
        setContentView(root)
    }
}
