package com.example.crosshair

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_NOTIF = 1

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("reticle", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var content: FrameLayout
    private val pages = ArrayList<View>()
    private val navItems = ArrayList<TextView>()

    // header
    private lateinit var statusChip: TextView

    // home
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var startBtn: TextView
    private lateinit var permBtn: TextView
    private lateinit var gBatt: RingGauge
    private lateinit var gCpu: RingGauge
    private lateinit var gGpu: RingGauge
    private lateinit var gRam: RingGauge
    private lateinit var gTemp: RingGauge
    private lateinit var gDisk: RingGauge
    private lateinit var hint: TextView
    private lateinit var appName: TextView
    private lateinit var appSub: TextView
    private lateinit var netText: TextView
    private lateinit var usageBtn: TextView

    // crosshair tab
    private lateinit var preview: CrosshairView

    // settings tab
    private lateinit var overlayPill: TextView
    private lateinit var usagePill: TextView
    private lateinit var notifPill: TextView

    private val ticker = object : Runnable {
        override fun run() {
            refreshStats()
            refreshOverlayUi()
            refreshPerms()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Theme.BG0
        window.navigationBarColor = Theme.BG1

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Theme.BG0, Theme.BG1)
            )
        }
        root.addView(buildHeader())

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        pages.add(scroll(buildHome()))
        pages.add(scroll(buildCrosshairTab()))
        pages.add(scroll(buildSettingsTab()))
        pages.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }

        root.addView(buildNav())
        setContentView(root)
        selectTab(prefs.getInt("tab", 0).coerceIn(0, 2))
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    // ================= helpers =================

    private fun label(s: String, sizeSp: Float, color: Int = Theme.TEXT, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = sizeSp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Theme.CARD, dp(24).toFloat(), Theme.STROKE, dp(1))
        setPadding(dp(18), dp(18), dp(18), dp(18))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(16), dp(8), dp(16), dp(8))
        }
    }

    private fun cardTitle(parent: LinearLayout, title: String, sub: String? = null) {
        parent.addView(label(title, 18f, Theme.TEXT, true))
        if (sub != null) parent.addView(label(sub, 13f, Theme.MUTED))
    }

    private fun scroll(v: View): View = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        addView(v)
    }

    private fun bigButton(onClick: () -> Unit): TextView = TextView(this).apply {
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setOnClickListener { onClick() }
    }

    private fun styleBtn(tv: TextView, s: String, c1: Int, c2: Int, fg: Int) {
        tv.text = s
        tv.setTextColor(fg)
        tv.background = gradient(c1, c2, dp(18).toFloat())
    }

    private fun tintSwitch(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(Theme.ACCENT, Theme.STROKE))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Theme.MUTED))
    }

    private fun switchRow(
        title: String,
        key: String,
        def: Boolean,
        desc: String? = null,
        onChange: (Boolean) -> Unit = {}
    ): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, 0)
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(label(title, 14f))
        if (desc != null) left.addView(label(desc, 12f, Theme.MUTED))
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, def)
        tintSwitch(sw)
        sw.setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean(key, c).apply()
            onChange(c)
        }
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(sw)
        return row
    }

    private fun chipStyle(tv: TextView, on: Boolean) {
        tv.background = if (on) {
            gradient(Theme.ACCENT, Theme.ACCENT2, dp(14).toFloat())
        } else {
            rounded(Theme.CARD2, dp(14).toFloat(), Theme.STROKE, dp(1))
        }
        tv.setTextColor(if (on) Color.BLACK else Theme.MUTED)
    }

    /** ตัวเลือกเรียงแถวแบบกว้างเท่ากัน ค่าที่เก็บคือ values[i] */
    private fun segmented(
        options: List<String>,
        values: List<Int>,
        key: String,
        def: Int,
        onChange: () -> Unit = {}
    ): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        val views = ArrayList<TextView>()
        fun restyle() {
            val sel = prefs.getInt(key, def)
            views.forEachIndexed { i, tv -> chipStyle(tv, values[i] == sel) }
        }
        options.forEachIndexed { i, name ->
            val tv = TextView(this).apply {
                text = name
                textSize = 13f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), dp(11), dp(6), dp(11))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                    setMargins(dp(3), 0, dp(3), 0)
                }
                setOnClickListener {
                    prefs.edit().putInt(key, values[i]).apply()
                    restyle()
                    onChange()
                }
            }
            views.add(tv)
            row.addView(tv)
        }
        restyle()
        return row
    }

    /** ชิปเลื่อนแนวนอน ค่าที่เก็บคือลำดับ (index) */
    private fun chipScroller(options: List<String>, key: String, def: Int, onChange: () -> Unit): View {
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(12), 0, 0)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = ArrayList<TextView>()
        fun restyle() {
            val sel = prefs.getInt(key, def)
            views.forEachIndexed { i, tv -> chipStyle(tv, i == sel) }
        }
        options.forEachIndexed { i, name ->
            val tv = TextView(this).apply {
                text = name
                textSize = 14f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), dp(12), dp(16), dp(12))
                layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply {
                    setMargins(0, 0, dp(8), 0)
                }
                setOnClickListener {
                    prefs.edit().putInt(key, i).apply()
                    restyle()
                    onChange()
                }
            }
            views.add(tv)
            row.addView(tv)
        }
        restyle()
        scroller.addView(row)
        return scroller
    }

    private fun slider(
        parent: LinearLayout,
        title: String,
        key: String,
        lo: Int,
        hi: Int,
        def: Int,
        suffix: String = "",
        onChange: (Int) -> Unit = {}
    ) {
        val value = prefs.getInt(key, def).coerceIn(lo, hi)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        val v = label("$value$suffix", 14f, Theme.ACCENT, true)
        head.addView(label(title, 14f), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(v)

        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = value - lo
        sb.progressTintList = ColorStateList.valueOf(Theme.ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(Theme.ACCENT)
        sb.progressBackgroundTintList = ColorStateList.valueOf(Theme.STROKE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val n = p + lo
                v.text = "$n$suffix"
                if (!fromUser) return
                prefs.edit().putInt(key, n).apply()
                onChange(n)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(head)
        parent.addView(sb)
    }

    // ================= header / nav =================

    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }
        val t = TextView(this).apply {
            text = "RETICLE"
            textSize = 26f
            setTextColor(Theme.TEXT)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.18f
        }
        row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        statusChip = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        row.addView(statusChip)
        return row
    }

    private fun buildNav(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Theme.CARD, dp(28).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                setMargins(dp(16), dp(8), dp(16), dp(12))
            }
        }
        val names = listOf("🎯 หน้าหลัก", "✛ เป้าเล็ง", "⚙ ตั้งค่า")
        names.forEachIndexed { i, n ->
            val tv = TextView(this).apply {
                text = n
                textSize = 13f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(4), dp(12), dp(4), dp(12))
                setOnClickListener { selectTab(i) }
            }
            navItems.add(tv)
            bar.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return bar
    }

    private fun selectTab(i: Int) {
        prefs.edit().putInt("tab", i).apply()
        pages.forEachIndexed { idx, v -> v.visibility = if (idx == i) View.VISIBLE else View.GONE }
        navItems.forEachIndexed { idx, tv ->
            val on = idx == i
            tv.setTextColor(if (on) Color.BLACK else Theme.MUTED)
            tv.background = if (on) gradient(Theme.ACCENT, Theme.ACCENT2, dp(22).toFloat()) else null
        }
    }

    // ================= tab 1: home =================

    private fun gaugeRow(a: RingGauge, b: RingGauge, c: RingGauge): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 3f
        }
        for (g in listOf(a, b, c)) {
            r.addView(g, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                setMargins(dp(6), dp(10), dp(6), dp(2))
            })
        }
        return r
    }

    private fun buildHome(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }

        // --- hero ---
        val hero = card()
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val avatar = ImageView(this).apply {
            setImageResource(R.drawable.floating_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Theme.CARD2)
                setStroke(dp(2), Theme.ACCENT)
            }
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
        }
        top.addView(avatar, LinearLayout.LayoutParams(dp(68), dp(68)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heroTitle = label("พร้อมเล็ง", 21f, Theme.TEXT, true)
        heroSub = label("เปิดเป้าทับเกม พร้อม HUD ข้อมูลเครื่อง", 13f, Theme.MUTED)
        titles.addView(heroTitle)
        titles.addView(heroSub)
        top.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })
        hero.addView(top)
        startBtn = bigButton { toggleOverlay() }
        hero.addView(startBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })
        permBtn = bigButton { openOverlaySettings() }
        permBtn.textSize = 14f
        styleBtn(permBtn, "⚠ ต้องอนุญาต 'แสดงทับแอปอื่น' ก่อน (แตะเพื่อตั้งค่า)", Theme.VIOLET, Theme.VIOLET, Color.WHITE)
        hero.addView(permBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        col.addView(hero)

        // --- gauges ---
        val stats = card()
        cardTitle(stats, "ข้อมูลเครื่องสด", "อัปเดตทุกวินาที")
        gBatt = RingGauge(this, "แบต", Theme.ACCENT, true)
        gCpu = RingGauge(this, "CPU", Theme.ACCENT2)
        gGpu = RingGauge(this, "GPU", Theme.VIOLET)
        gRam = RingGauge(this, "RAM", Theme.ACCENT2)
        gTemp = RingGauge(this, "อุณหภูมิ", Theme.ACCENT)
        gDisk = RingGauge(this, "พื้นที่", Theme.VIOLET)
        stats.addView(gaugeRow(gBatt, gCpu, gGpu))
        stats.addView(gaugeRow(gRam, gTemp, gDisk))
        hint = label("", 12f, Theme.MUTED)
        hint.setPadding(0, dp(10), 0, 0)
        hint.visibility = View.GONE
        stats.addView(hint)
        col.addView(stats)

        // --- foreground app ---
        val app = card()
        cardTitle(app, "แอปที่ใช้อยู่", "ชื่อแอปที่เปิดอยู่ตอนนี้")
        appName = label("—", 22f, Theme.ACCENT, true)
        appName.setPadding(0, dp(12), 0, 0)
        app.addView(appName)
        appSub = label("", 12f, Theme.MUTED)
        app.addView(appSub)
        netText = label("", 13f, Theme.TEXT)
        netText.setPadding(0, dp(10), 0, 0)
        app.addView(netText)
        usageBtn = bigButton { openUsageSettings() }
        usageBtn.textSize = 14f
        styleBtn(usageBtn, "อนุญาตให้ดูแอปที่ใช้งาน (Usage Access)", Theme.VIOLET, Theme.VIOLET, Color.WHITE)
        app.addView(usageBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        col.addView(app)

        return col
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
        } else if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "ต้องอนุญาตแสดงทับแอปอื่นก่อน", Toast.LENGTH_LONG).show()
            openOverlaySettings()
        } else {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        handler.postDelayed({ refreshOverlayUi() }, 400)
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun openUsageSettings() {
        try {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "เปิดหน้าตั้งค่าไม่ได้ ไปที่ ตั้งค่า > ความเป็นส่วนตัว > การเข้าถึงข้อมูลการใช้งาน", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshStats() {
        val b = Stats.battery(this)
        gBatt.update(
            if (b.percent >= 0) "${b.percent}%" else "—",
            if (b.percent >= 0) b.percent else null
        )

        val cpu = Stats.cpuPercent()
        gCpu.update(if (cpu != null) "$cpu%" else "N/A", cpu)

        val gpu = Stats.gpuPercent()
        gGpu.update(if (gpu != null) "$gpu%" else "N/A", gpu)

        val m = Stats.memory(this)
        gRam.update("${m.pct}%", m.pct)

        gTemp.update(String.format(Locale.US, "%.0f°", b.tempC), (b.tempC * 100f / 60f).toInt())

        val d = Stats.diskPercent()
        gDisk.update("$d%", d)

        val notes = ArrayList<String>()
        if (gpu == null) notes.add("GPU: เครื่องนี้ไม่เปิดให้แอปอ่านค่า (ระบบ Android จำกัด)")
        if (cpu == null) notes.add("CPU: เครื่องนี้ไม่เปิดให้แอปอ่านค่า")
        hint.text = notes.joinToString("\n")
        hint.visibility = if (notes.isEmpty()) View.GONE else View.VISIBLE

        if (!Stats.hasUsageAccess(this)) {
            appName.text = "ยังไม่ได้อนุญาต"
            appSub.text = "กดปุ่มด้านล่างแล้วเปิดสวิตช์ให้แอปนี้"
            usageBtn.visibility = View.VISIBLE
        } else {
            usageBtn.visibility = View.GONE
            val pkg = Stats.foregroundPackage(this)
            if (pkg == null) {
                appName.text = "—"
                appSub.text = "ยังไม่พบแอปที่เปิดอยู่"
            } else if (pkg == packageName) {
                appName.text = "Reticle"
                appSub.text = "สลับไปเปิดเกม แล้วดูชื่อแอปได้ที่ HUD"
            } else {
                appName.text = Stats.appLabel(this, pkg)
                appSub.text = pkg
            }
        }
        val n = Stats.netSpeed()
        netText.text = if (n == null) "" else
            "เน็ต  ↓ " + Stats.formatSpeed(n.first) + "/s   ↑ " + Stats.formatSpeed(n.second) + "/s"
    }

    private fun refreshOverlayUi() {
        val on = OverlayService.running
        if (on) {
            styleBtn(startBtn, "■  หยุดเป้าเล็ง", Theme.DANGER, Color.parseColor("#FF7A59"), Color.WHITE)
            heroTitle.text = "กำลังทำงาน"
            heroSub.text = "แตะรูปนายที่ลอยอยู่เพื่อเปิดแผงปุ่ม"
        } else {
            styleBtn(startBtn, "▶  เริ่มเป้าเล็ง", Theme.ACCENT, Theme.ACCENT2, Color.BLACK)
            heroTitle.text = "พร้อมเล็ง"
            heroSub.text = "เปิดเป้าทับเกม พร้อม HUD ข้อมูลเครื่อง"
        }
        val chipText = if (on) "● ทำงานอยู่" else "● ปิดอยู่"
        val chipColor = if (on) Theme.ACCENT else Theme.MUTED
        statusChip.text = chipText
        statusChip.setTextColor(chipColor)
        statusChip.background = rounded(Theme.CARD, dp(14).toFloat(), chipColor, dp(1))
        permBtn.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
    }

    // ================= tab 2: crosshair =================

    private fun buildCrosshairTab(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }

        // --- preview ---
        val pv = card()
        cardTitle(pv, "ตัวอย่างเป้า")
        preview = CrosshairView(this)
        val box = FrameLayout(this).apply {
            background = gradient(Color.parseColor("#0B2530"), Color.parseColor("#0A1220"), dp(18).toFloat(),
                GradientDrawable.Orientation.TOP_BOTTOM)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        box.addView(GridBackdrop(this), FrameLayout.LayoutParams(MATCH, MATCH))
        box.addView(preview, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        pv.addView(box, LinearLayout.LayoutParams(MATCH, dp(190)).apply { topMargin = dp(12) })
        col.addView(pv)

        // --- style ---
        val st = card()
        cardTitle(st, "รูปแบบเป้า", "เลือกแบบที่ชอบ")
        st.addView(
            chipScroller(
                listOf("✛ กากบาท", "┬ ตัว T", "• จุด", "◯ วงแหวน", "✕ เฉียง", "◎ วงล้อ"),
                "style", 0
            ) { preview.reload() }
        )
        col.addView(st)

        // --- color ---
        val cl = card()
        cardTitle(cl, "สี")
        val colors = listOf(
            Theme.ACCENT, Color.WHITE, Color.parseColor("#FF3B3B"), Color.parseColor("#FFE600"),
            Color.parseColor("#00E5FF"), Color.parseColor("#FF4DFF"), Color.parseColor("#FF9100"),
            Color.parseColor("#39FF14")
        )
        val swatches = ArrayList<View>()
        fun restyleSwatches() {
            val sel = prefs.getInt("color", Theme.ACCENT)
            swatches.forEachIndexed { i, v ->
                val ring = if (colors[i] == sel) Color.WHITE else Theme.STROKE
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(colors[i])
                    setStroke(dp(if (colors[i] == sel) 3 else 1), ring)
                }
            }
        }
        val swRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        colors.forEachIndexed { i, c ->
            val v = View(this)
            v.setOnClickListener {
                prefs.edit().putInt("color", c).apply()
                restyleSwatches()
                preview.reload()
            }
            swatches.add(v)
            swRow.addView(v, LinearLayout.LayoutParams(0, dp(34), 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        restyleSwatches()
        cl.addView(swRow)
        slider(cl, "เฉดสีกำหนดเอง", "hue", 0, 360, 0, "°") { n ->
            prefs.edit().putInt("color", Color.HSVToColor(floatArrayOf(n.toFloat(), 1f, 1f))).apply()
            restyleSwatches()
            preview.reload()
        }
        col.addView(cl)

        // --- shape ---
        val sh = card()
        cardTitle(sh, "รูปทรง")
        slider(sh, "ขนาด", "size", 16, 120, 40, " dp") { preview.reload() }
        slider(sh, "ความหนา", "thick", 1, 8, 2, " dp") { preview.reload() }
        slider(sh, "ช่องว่างกลางเป้า", "gap", 0, 30, 6, " dp") { preview.reload() }
        slider(sh, "ความโปร่งใส", "alpha", 20, 100, 100, "%") { preview.reload() }
        sh.addView(switchRow("เส้นขอบดำ", "outline", true, "ช่วยให้เห็นเป้าบนพื้นหลังสว่าง") { preview.reload() })
        sh.addView(switchRow("จุดกลาง", "dot", true) { preview.reload() })
        col.addView(sh)
        val posCard = card()
        cardTitle(posCard, "ตำแหน่งเป้า", "ขยับให้ตรงกลางจอเกมของคุณ")
        slider(posCard, "ซ้าย (-) / ขวา (+)", "offx", -300, 300, 0, " dp")
        slider(posCard, "ขึ้น (-) / ลง (+)", "offy", -300, 300, 0, " dp")
        val resetPos = bigButton {
            prefs.edit().putInt("offx", 0).putInt("offy", 0).apply()
            recreate()
        }
        resetPos.textSize = 14f
        styleBtn(resetPos, "จัดกลางจอ", Theme.CARD2, Theme.CARD2, Color.WHITE)
        posCard.addView(resetPos, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })
        col.addView(posCard)

        val resetAll = bigButton {
            prefs.edit()
                .remove("style").remove("size").remove("thick").remove("gap").remove("alpha")
                .remove("color").remove("hue").remove("dot").remove("outline")
                .putInt("offx", 0).putInt("offy", 0)
                .apply()
            recreate()
        }
        resetAll.textSize = 14f
        styleBtn(resetAll, "รีเซ็ตเป้าเป็นค่าเริ่มต้น", Theme.CARD2, Theme.CARD2, Theme.MUTED)
        col.addView(resetAll, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(16), dp(8), dp(16), dp(8))
        })
        return col
    }

    // ================= tab 3: settings =================

    private fun pill(tv: TextView, ok: Boolean) {
        tv.text = if (ok) "✓ แล้ว" else "อนุญาต"
        tv.setTextColor(if (ok) Color.BLACK else Color.WHITE)
        tv.background = rounded(if (ok) Theme.ACCENT else Theme.VIOLET, dp(14).toFloat())
    }

    private fun permRow(parent: LinearLayout, title: String, desc: String, pill: TextView, onClick: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, 0)
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(label(title, 14f))
        left.addView(label(desc, 12f, Theme.MUTED))
        pill.textSize = 12f
        pill.typeface = Typeface.DEFAULT_BOLD
        pill.setPadding(dp(14), dp(8), dp(14), dp(8))
        pill.setOnClickListener { onClick() }
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(pill)
        parent.addView(row)
    }

    private fun notifGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun refreshPerms() {
        pill(overlayPill, Settings.canDrawOverlays(this))
        pill(usagePill, Stats.hasUsageAccess(this))
        pill(notifPill, notifGranted())
    }

    private fun buildSettingsTab(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }

        val hud = card()
        cardTitle(hud, "HUD ข้อมูลเครื่อง", "เลือกว่าจะให้โชว์อะไรบนจอเกม")
        hud.addView(switchRow("เปิด HUD", "hud_on", true))
        hud.addView(switchRow("แบตเตอรี่ + อุณหภูมิ", "hud_batt", true))
        hud.addView(switchRow("แอปที่ใช้อยู่", "hud_app", true, "ต้องอนุญาต Usage Access"))
        hud.addView(switchRow("CPU", "hud_cpu", true))
        hud.addView(switchRow("GPU", "hud_gpu", true))
        hud.addView(switchRow("RAM", "hud_ram", true))
        hud.addView(switchRow("ความเร็วเน็ต", "hud_net", false))
        hud.addView(switchRow("เวลา", "hud_clock", false))
        hud.addView(label("ตำแหน่ง HUD", 14f).apply { setPadding(0, dp(16), 0, 0) })
        hud.addView(segmented(listOf("ซ้าย", "กลาง", "ขวา"), listOf(0, 1, 2), "hud_pos", 0))
        slider(hud, "ความโปร่งใสพื้นหลัง HUD", "hud_alpha", 20, 100, 85, "%")
        col.addView(hud)

        val ov = card()
        cardTitle(ov, "แผงลอย")
        ov.addView(switchRow("แสดงเป้าเล็ง", "cross_on", true))
        ov.addView(switchRow("แสดงแผงปุ่มลอย", "move_on", true, "รูปนายกับปุ่มลูกศรเลื่อนเป้า"))
        ov.addView(label("ระยะก้าวของลูกศร", 14f).apply { setPadding(0, dp(16), 0, 0) })
        ov.addView(segmented(listOf("1 px", "5 px", "10 px"), listOf(1, 5, 10), "step", 1))
        col.addView(ov)

        val pm = card()
        cardTitle(pm, "สิทธิ์ที่ใช้", "แอปนี้ขอเท่าที่จำเป็น")
        overlayPill = TextView(this)
        usagePill = TextView(this)
        notifPill = TextView(this)
        permRow(pm, "แสดงทับแอปอื่น", "จำเป็นสำหรับเป้าและ HUD", overlayPill) { openOverlaySettings() }
        permRow(pm, "ดูแอปที่ใช้งาน", "เพื่อบอกชื่อแอปที่เปิดอยู่", usagePill) { openUsageSettings() }
        permRow(pm, "การแจ้งเตือน", "แสดงสถานะตอนเป้าทำงาน", notifPill) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
        }
        col.addView(pm)

        val tip = card()
        tip.addView(label("เคล็ดลับ", 15f, Theme.TEXT, true))
        tip.addView(
            label(
                "เริ่มเป้าแล้วเปิดเกม แตะรูปนายที่ลอยอยู่เพื่อเปิด/ปิดแผงปุ่ม ลากรูปนายเพื่อย้ายแผง " +
                    "ปุ่ม ◎ ซ่อนเป้า, ×1/×5/×10 เปลี่ยนระยะก้าว, HUD ซ่อนข้อมูลเครื่อง " +
                    "ปิดเป้าได้จากปุ่ม \"หยุด\" ในแถบแจ้งเตือน",
                13f, Theme.MUTED
            )
        )
        col.addView(tip)
        return col
    }
}
