package com.example.crosshair

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("crosshair", MODE_PRIVATE) }
    private lateinit var preview: CrosshairView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
                        setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Crosshair HUD"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "ทำตามลำดับ 1 → 2 → 3 (ข้อ 2 ใช้แสดงชื่อแอปที่กำลังเปิดอยู่)"
            setPadding(0, pad / 2, 0, pad / 2)
        })

        // ตัวอย่างเป้า
        preview = CrosshairView(this)
        val box = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#444444")) }
        box.addView(preview, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        root.addView(box, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (180 * resources.displayMetrics.density).toInt()))

        fun slider(label: String, key: String, lo: Int, hi: Int, def: Int) {
            val value = prefs.getInt(key, def)
            val tv = TextView(this).apply {
                text = "$label: $value"
                setPadding(0, pad / 2, 0, 0)
            }
            val sb = SeekBar(this).apply {
                this.max = hi - lo
                progress = value - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        val v = p + lo
                        tv.text = "$label: $v"
                        prefs.edit().putInt(key, v).apply()
                        preview.reload()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            root.addView(tv)
            root.addView(sb)
        }
        slider("ขนาด", "size", 20, 160, 48)
        slider("ความหนา", "thick", 1, 8, 2)
        slider("สี (เฉดสี)", "hue", 0, 360, 0)
        slider("ความเข้มสี (0 = ขาว)", "sat", 0, 100, 100)

        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        button("1. อนุญาตแสดงทับแอปอื่น") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. อนุญาตเข้าถึงข้อมูลการใช้งานแอป") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        button("3. เริ่มเป้ากลางจอ + HUD") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "ยังไม่ได้อนุญาตแสดงทับแอปอื่น (ข้อ 1)", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this, OverlayService::class.java))
            }
        }
        button("รีเซ็ตค่าเป้า") {
            prefs.edit().clear().apply()
            recreate()
        }
        button("หยุด") {
            stopService(Intent(this, OverlayService::class.java))
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
