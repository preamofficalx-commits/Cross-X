package com.example.crosshair

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * เป้าเล็ง 6 แบบ: 0 กากบาท, 1 ตัว T, 2 จุด, 3 วงแหวน, 4 กากบาทเฉียง, 5 วงล้อ
 * อ่านค่าทั้งหมดจาก SharedPreferences "reticle"
 */
class CrosshairView(context: Context) : View(context) {
    private val dp = resources.displayMetrics.density
    private val prefs = context.getSharedPreferences("reticle", Context.MODE_PRIVATE)

    private var style = 0
    private var sizePx = (40 * dp).toInt()
    private var lenPx = 18f * dp
    private var gapPx = 6f * dp
    private var thickPx = 2f * dp
    private var showDot = true
    private var showOutline = true

    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dotOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }

    init {
        reload()
    }

    fun reload() {
        style = prefs.getInt("style", 0)
        val sizeDp = prefs.getInt("size", 40)
        val thickDp = prefs.getInt("thick", 2)
        val gapDp = prefs.getInt("gap", 6)
        val alpha = prefs.getInt("alpha", 100).coerceIn(10, 100)
        val color = prefs.getInt("color", Theme.ACCENT)
        showDot = prefs.getBoolean("dot", true)
        showOutline = prefs.getBoolean("outline", true)

        sizePx = (sizeDp * dp).toInt().coerceAtLeast(1)
        thickPx = thickDp * dp
        lenPx = sizePx / 2f - (thickDp + 2) * dp / 2f
        gapPx = (gapDp * dp).coerceAtMost(lenPx - 2f * dp).coerceAtLeast(0f)

        val a = alpha * 255 / 100
        line.color = color
        line.alpha = a
        line.strokeWidth = thickPx
        outline.alpha = a * 8 / 10
        outline.strokeWidth = thickPx + 2f * dp
        dot.color = color
        dot.alpha = a
        dotOutline.alpha = a * 8 / 10
        requestLayout()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(sizePx, sizePx)

    private fun shape(c: Canvas, cx: Float, cy: Float, p: Paint) {
        when (style) {
            0 -> {
                c.drawLine(cx - lenPx, cy, cx - gapPx, cy, p)
                c.drawLine(cx + gapPx, cy, cx + lenPx, cy, p)
                c.drawLine(cx, cy - lenPx, cx, cy - gapPx, p)
                c.drawLine(cx, cy + gapPx, cx, cy + lenPx, p)
            }
            1 -> {
                c.drawLine(cx - lenPx, cy, cx - gapPx, cy, p)
                c.drawLine(cx + gapPx, cy, cx + lenPx, cy, p)
                c.drawLine(cx, cy + gapPx, cx, cy + lenPx, p)
            }
            3 -> {
                c.drawCircle(cx, cy, lenPx * 0.8f, p)
            }
            4 -> {
                val a = gapPx * 0.7f
                val b = lenPx * 0.75f
                c.drawLine(cx - b, cy - b, cx - a, cy - a, p)
                c.drawLine(cx + a, cy + a, cx + b, cy + b, p)
                c.drawLine(cx + b, cy - b, cx + a, cy - a, p)
                c.drawLine(cx - a, cy + a, cx - b, cy + b, p)
            }
            5 -> {
                val r = lenPx * 0.55f
                c.drawCircle(cx, cy, r, p)
                val t0 = lenPx * 0.8f
                c.drawLine(cx - lenPx, cy, cx - t0, cy, p)
                c.drawLine(cx + t0, cy, cx + lenPx, cy, p)
                c.drawLine(cx, cy - lenPx, cx, cy - t0, p)
                c.drawLine(cx, cy + t0, cx, cy + lenPx, p)
            }
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        if (style == 2) {
            val r = maxOf(2f * dp, thickPx * 1.6f)
            if (showOutline) c.drawCircle(cx, cy, r + dp, dotOutline)
            c.drawCircle(cx, cy, r, dot)
            return
        }
        if (showOutline) shape(c, cx, cy, outline)
        shape(c, cx, cy, line)
        if (showDot) {
            val r = maxOf(1.2f * dp, thickPx * 0.7f)
            if (showOutline) c.drawCircle(cx, cy, r + dp, dotOutline)
            c.drawCircle(cx, cy, r, dot)
        }
    }
}
