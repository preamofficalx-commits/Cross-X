package com.example.crosshair

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/** เป้ากลางจอ: ขนาด ความหนา และสี ปรับได้จากหน้าแอป (อ่านค่าจาก SharedPreferences) */
class CrosshairView(context: Context) : View(context) {
    private val dp = resources.displayMetrics.density
    private val prefs = context.getSharedPreferences("crosshair", Context.MODE_PRIVATE)

    private var sizePx = (48 * dp).toInt()
    private var lenPx = 20 * dp
    private var gapPx = 5 * dp

    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    init {
        reload()
    }

    fun reload() {
        val sizeDp = prefs.getInt("size", 48)
        val thickDp = prefs.getInt("thick", 2)
        val hue = prefs.getInt("hue", 0)
        val sat = prefs.getInt("sat", 100)
        val color = Color.HSVToColor(floatArrayOf(hue.toFloat(), sat / 100f, 1f))

        sizePx = (sizeDp * dp).toInt()
        lenPx = (sizeDp / 2f - 4f) * dp
        gapPx = maxOf(3f, sizeDp * 0.1f) * dp
        line.color = color
        line.strokeWidth = thickDp * dp
        outline.strokeWidth = (thickDp + 2) * dp
        dot.color = color
        requestLayout()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(sizePx, sizePx)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        for (p in listOf(outline, line)) {
            c.drawLine(cx - lenPx, cy, cx - gapPx, cy, p)
            c.drawLine(cx + gapPx, cy, cx + lenPx, cy, p)
            c.drawLine(cx, cy - lenPx, cx, cy - gapPx, p)
            c.drawLine(cx, cy + gapPx, cx, cy + lenPx, p)
        }
        c.drawCircle(cx, cy, maxOf(1.5f, line.strokeWidth / dp * 0.75f) * dp, dot)
    }
}
