package com.zeropoint.hud

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** สร้างข้อความ HUD (ใช้ร่วมกันระหว่างเลเยอร์ทับหน้าจอกับหน้าตัวอย่างในแอป) */
object Hud {

    private class Seg(val label: String, val value: String, val color: Int)

    private val timeFmt = SimpleDateFormat("HH:mm", Locale.US)

    fun textSizeSp(p: SharedPreferences): Float = when (p.getInt("hud_size", 1)) {
        0 -> 10f
        2 -> 14f
        else -> 12f
    }

    fun build(ctx: Context, p: SharedPreferences, sessionStart: Long): SpannableStringBuilder {
        val compact = p.getInt("hud_mode", 0) == 1
        val lines = ArrayList<List<Seg>>()

        // แอปที่ใช้อยู่
        if (p.getBoolean("hud_app", true)) {
            val fg = Stats.foreground(ctx)
            var name = fg?.label ?: "—"
            val max = if (compact) 12 else 24
            if (name.length > max) name = name.take(max - 1) + "…"
            lines.add(listOf(Seg("APP", name, Theme.TEXT)))
        }

        // แบตเตอรี่
        if (p.getBoolean("hud_bat", true)) {
            val b = Stats.battery(ctx)
            val segs = ArrayList<Seg>()
            if (b.percent >= 0) {
                segs.add(Seg("BAT", "${b.percent}%" + (if (b.charging) "⚡" else ""), batteryColor(b.percent)))
            } else {
                segs.add(Seg("BAT", "N/A", Theme.MUTED))
            }
            segs.add(Seg("", String.format(Locale.US, "%.1f°C", b.tempC), tempColor(b.tempC)))
            if (!compact && b.powerW != null) {
                segs.add(Seg("", String.format(Locale.US, "%.1fW", b.powerW), Theme.TEXT))
            }
            lines.add(segs)
        }

        // CPU / GPU
        val cg = ArrayList<Seg>()
        if (p.getBoolean("hud_cpu", true)) {
            val cpu = Stats.cpuPercent()
            cg.add(Seg("CPU", cpu?.let { "$it%" } ?: "N/A", cpu?.let { levelColor(it) } ?: Theme.MUTED))
            if (!compact) {
                Stats.cpuTopGhz()?.let {
                    cg.add(Seg("", String.format(Locale.US, "%.1fGHz", it), Theme.LABEL))
                }
            }
        }
        if (p.getBoolean("hud_gpu", true)) {
            val gpu = Stats.gpuPercent()
            val txt = gpu?.let { (if (Stats.gpuEstimated) "~" else "") + "$it%" } ?: "N/A"
            cg.add(Seg("GPU", txt, gpu?.let { levelColor(it) } ?: Theme.MUTED))
        }
        if (cg.isNotEmpty()) lines.add(cg)

        // RAM / Ping
        val rp = ArrayList<Seg>()
        if (p.getBoolean("hud_ram", true)) {
            val m = Stats.memory(ctx)
            rp.add(Seg("RAM", "${m.pct}%", levelColor(m.pct)))
        }
        if (p.getBoolean("hud_ping", true)) {
            val ms = Stats.pingMs
            rp.add(Seg("PING", if (ms >= 0) "${ms}ms" else "—", pingColor(ms)))
        }
        if (rp.isNotEmpty()) lines.add(rp)

        // เวลา / เวลาที่เปิดเป้า
        if (p.getBoolean("hud_time", true)) {
            val sec = ((SystemClock.elapsedRealtime() - sessionStart) / 1000).coerceAtLeast(0)
            val h = sec / 3600
            val m = (sec % 3600) / 60
            val s = sec % 60
            val dur = if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
            else String.format(Locale.US, "%02d:%02d", m, s)
            lines.add(
                listOf(
                    Seg("", timeFmt.format(Date()), Theme.TEXT),
                    Seg("ON", dur, Theme.LABEL)
                )
            )
        }

        val sb = SpannableStringBuilder()
        if (lines.isEmpty()) {
            sb.append("HUD ว่างอยู่")
            return sb
        }
        if (compact) {
            val flat = lines.flatten()
            flat.forEachIndexed { i, seg ->
                if (i > 0) sb.append("  ")
                append(sb, seg)
            }
        } else {
            lines.forEachIndexed { li, segs ->
                if (li > 0) sb.append('\n')
                segs.forEachIndexed { i, seg ->
                    if (i > 0) sb.append("  ")
                    append(sb, seg)
                }
            }
        }
        return sb
    }

    private fun append(sb: SpannableStringBuilder, seg: Seg) {
        if (seg.label.isNotEmpty()) {
            val s = sb.length
            sb.append(seg.label).append(' ')
            sb.setSpan(ForegroundColorSpan(Theme.LABEL), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val s2 = sb.length
        sb.append(seg.value)
        sb.setSpan(ForegroundColorSpan(seg.color), s2, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
}
