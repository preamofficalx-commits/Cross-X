package com.zeropoint.hud

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

data class BatteryState(
    val percent: Int,
    val tempC: Float,
    val charging: Boolean,
    val voltageV: Float,
    val powerW: Float?
)

data class MemState(val usedMb: Long, val totalMb: Long) {
    val pct: Int get() = if (totalMb > 0) (usedMb * 100 / totalMb).toInt() else 0
}

data class FgApp(val pkg: String, val label: String)

object Stats {

    // ================= แบตเตอรี่ =================

    fun battery(ctx: Context): BatteryState {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return BatteryState(-1, 0f, false, 0f, null)
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val volt = mv / 1000f

        // กระแสไฟ: เครื่องส่วนใหญ่รายงานเป็นไมโครแอมป์ บางรุ่นรายงานเป็นมิลลิแอมป์ จึงเดาหน่วยจากขนาดตัวเลข
        var power: Float? = null
        try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (raw != Int.MIN_VALUE && raw != 0 && volt > 0f) {
                val amps = if (abs(raw) > 20000) raw / 1_000_000f else raw / 1000f
                power = abs(amps) * volt
            }
        } catch (e: Exception) {
        }
        return BatteryState(pct, temp, charging, volt, power)
    }

    // ================= CPU =================

    private var procOk = true
    private var lastTotal = 0L
    private var lastIdle = 0L
    private var cpuCache: Int? = null
    private var cpuCacheAt = 0L

    /** อ่านโหลดจาก /proc/stat (หลายเครื่องบล็อก) ถ้าอ่านไม่ได้จะประเมินจากความเร็วคล็อก */
    @Synchronized
    fun cpuPercent(): Int? {
        val now = SystemClock.elapsedRealtime()
        if (now - cpuCacheAt < 800) return cpuCache
        cpuCacheAt = now
        cpuCache = procStatPercent() ?: cpuFreqPercent()
        return cpuCache
    }

    private fun procStatPercent(): Int? {
        if (!procOk) return null
        val line: String? = try {
            File("/proc/stat").bufferedReader().use { it.readLine() }
        } catch (e: Exception) {
            null
        }
        if (line == null) {
            procOk = false
            return null
        }
        val p = line.trim().split(Regex("\\s+"))
        if (p.size < 8 || p[0] != "cpu") {
            procOk = false
            return null
        }
        val v = p.subList(1, 8).map { it.toLongOrNull() ?: 0L }
        val idle = v[3] + v[4]
        val total = v.sum()
        val first = lastTotal == 0L
        val dTotal = total - lastTotal
        val dIdle = idle - lastIdle
        lastTotal = total
        lastIdle = idle
        if (first) return 0
        if (dTotal <= 0) return null
        return ((dTotal - dIdle) * 100 / dTotal).toInt().coerceIn(0, 100)
    }

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().toLong()
    } catch (e: Exception) {
        null
    }

    private fun cpuFreqPercent(): Int? {
        var sum = 0.0
        var n = 0
        val cores = Runtime.getRuntime().availableProcessors()
        for (c in 0 until cores) {
            val base = "/sys/devices/system/cpu/cpu$c/cpufreq/"
            val cur = readLong(base + "scaling_cur_freq") ?: continue
            val max = readLong(base + "cpuinfo_max_freq") ?: readLong(base + "scaling_max_freq") ?: continue
            if (max <= 0) continue
            sum += cur.toDouble() / max
            n++
        }
        if (n == 0) return null
        return (sum / n * 100).toInt().coerceIn(0, 100)
    }

    /** คล็อกของคอร์ที่เร็วที่สุดตอนนี้ (GHz) */
    fun cpuTopGhz(): Float? {
        var best = 0L
        val cores = Runtime.getRuntime().availableProcessors()
        for (c in 0 until cores) {
            val f = readLong("/sys/devices/system/cpu/cpu$c/cpufreq/scaling_cur_freq") ?: continue
            if (f > best) best = f
        }
        return if (best > 0) best / 1_000_000f else null
    }

    // ================= GPU =================

    @Volatile
    var gpuEstimated = false
        private set

    private val gpuBusyPaths = listOf(
        "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage", // Qualcomm Adreno
        "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load",
        "/sys/kernel/gpu/gpu_busy",
        "/sys/devices/platform/13000000.mali/utilization", // Mali
        "/sys/class/misc/mali0/device/utilisation",
        "/sys/module/ged/parameters/gpu_loading", // MediaTek
        "/sys/kernel/ged/hal/gpu_utilization"
    )

    private val gpuFreqPairs = listOf(
        "/sys/class/kgsl/kgsl-3d0/gpuclk" to "/sys/class/kgsl/kgsl-3d0/max_gpuclk",
        "/sys/class/kgsl/kgsl-3d0/devfreq/cur_freq" to "/sys/class/kgsl/kgsl-3d0/devfreq/max_freq"
    )

    fun gpuPercent(): Int? {
        for (path in gpuBusyPaths) {
            try {
                val n = Regex("\\d+").find(File(path).readText())?.value?.toInt()
                if (n != null) {
                    gpuEstimated = false
                    return n.coerceIn(0, 100)
                }
            } catch (e: Exception) {
            }
        }
        // ไม่มีค่าโหลดตรง ๆ → ประเมินจากคล็อก GPU เทียบคล็อกสูงสุด
        for ((cur, max) in gpuFreqPairs) {
            val c = readLong(cur)
            val m = readLong(max)
            if (c != null && m != null && m > 0) {
                gpuEstimated = true
                return (c * 100 / m).toInt().coerceIn(0, 100)
            }
        }
        return null
    }

    // ================= RAM / Disk / Thermal =================

    fun memory(ctx: Context): MemState {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / (1024 * 1024)
        val used = (mi.totalMem - mi.availMem) / (1024 * 1024)
        return MemState(used, total)
    }

    fun diskPercent(): Int = try {
        val s = StatFs(Environment.getDataDirectory().path)
        val total = s.totalBytes
        val free = s.availableBytes
        if (total > 0) ((total - free) * 100 / total).toInt() else 0
    } catch (e: Exception) {
        0
    }

    /** สถานะความร้อนที่ระบบรายงาน (Android 10+) */
    fun thermalLabel(ctx: Context): String? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                0 -> "ปกติ"
                1 -> "อุ่น"
                2 -> "ร้อนปานกลาง"
                3 -> "ร้อนมาก"
                4 -> "วิกฤต"
                5 -> "ฉุกเฉิน"
                6 -> "ใกล้ดับ"
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ================= Ping =================

    @Volatile
    var pingMs: Int = -1
        private set

    private var pingUsers = 0
    private var pingThread: Thread? = null

    @Volatile
    private var pingRun = false

    @Synchronized
    fun startPing() {
        pingUsers++
        if (pingThread != null) return
        pingRun = true
        pingThread = Thread {
            while (pingRun) {
                val t0 = SystemClock.elapsedRealtime()
                pingMs = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                    (SystemClock.elapsedRealtime() - t0).toInt()
                } catch (e: Exception) {
                    -1
                }
                try {
                    Thread.sleep(2000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.apply {
            isDaemon = true
            start()
        }
    }

    @Synchronized
    fun stopPing() {
        pingUsers = (pingUsers - 1).coerceAtLeast(0)
        if (pingUsers == 0) {
            pingRun = false
            pingThread?.interrupt()
            pingThread = null
            pingMs = -1
        }
    }

    // ================= แอปที่ใช้อยู่ =================

    @Suppress("DEPRECATION")
    fun hasUsageAccess(ctx: Context): Boolean {
        return try {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
                )
            } else {
                ops.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    private var fgLastQuery = 0L
    private var fgPkg: String? = null
    private val labelCache = HashMap<String, String>()

    @Suppress("DEPRECATION")
    @Synchronized
    fun foreground(ctx: Context): FgApp? {
        if (!hasUsageAccess(ctx)) return null
        return try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (fgLastQuery == 0L) now - 6 * 3600_000L else fgLastQuery - 2000
            val events = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) fgPkg = e.packageName
            }
            fgLastQuery = now
            val pkg = fgPkg ?: return null
            FgApp(pkg, labelOf(ctx, pkg))
        } catch (e: Exception) {
            null
        }
    }

    private fun labelOf(ctx: Context, pkg: String): String = labelCache.getOrPut(pkg) {
        try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg.substringAfterLast('.')
        }
    }
}
