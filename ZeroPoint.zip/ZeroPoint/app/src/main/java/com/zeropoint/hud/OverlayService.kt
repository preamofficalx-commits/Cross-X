package com.zeropoint.hud

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** วางเป้าเล็ง + HUD + ปุ่มลอย (รูปเดิม) ทับหน้าจอ */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.zeropoint.hud.STOP"
        private const val CHANNEL = "zp_overlay"

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private var crosshair: CrosshairView? = null
    private var crosshairLp: WindowManager.LayoutParams? = null
    private var hudBox: LinearLayout? = null
    private var hudText: TextView? = null
    private var hudLp: WindowManager.LayoutParams? = null
    private var controls: View? = null
    private var hudBtn: TextView? = null
    private var sessionStart = 0L
    private var pingOn = false

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("zeropoint", MODE_PRIVATE) }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        crosshair?.reload()
        applyOffset()
        applyHudStyle()
        applyVisibility()
        syncPing()
        refreshHudBtn()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (prefs.getBoolean("hud_on", true)) {
                hudText?.text = Hud.build(this@OverlayService, prefs, sessionStart)
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sessionStart = SystemClock.elapsedRealtime()
        addCrosshair()
        addHud()
        addControls()
        applyHudStyle()
        applyVisibility()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        syncPing()
        running = true
        handler.post(tick)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        runCatching { prefs.unregisterOnSharedPreferenceChangeListener(prefListener) }
        if (pingOn) {
            Stats.stopPing()
            pingOn = false
        }
        crosshair?.let { v -> runCatching { wm.removeView(v) } }
        hudBox?.let { v -> runCatching { wm.removeView(v) } }
        controls?.let { v -> runCatching { wm.removeView(v) } }
        super.onDestroy()
    }

    // ================= Window helpers =================

    private fun overlayParams(touchable: Boolean, gravity: Int): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }
    }

    private fun syncPing() {
        val want = prefs.getBoolean("hud_ping", true) && prefs.getBoolean("hud_on", true)
        if (want && !pingOn) {
            Stats.startPing()
            pingOn = true
        } else if (!want && pingOn) {
            Stats.stopPing()
            pingOn = false
        }
    }

    // ================= เป้าเล็ง =================

    private fun addCrosshair() {
        val v = CrosshairView(this)
        crosshair = v
        val lp = overlayParams(false, Gravity.CENTER)
        lp.x = (prefs.getInt("offx", 0) * resources.displayMetrics.density).toInt()
        lp.y = (prefs.getInt("offy", 0) * resources.displayMetrics.density).toInt()
        crosshairLp = lp
        wm.addView(v, lp)
    }

    private fun applyOffset() {
        val v = crosshair ?: return
        val lp = crosshairLp ?: return
        val d = resources.displayMetrics.density
        lp.x = (prefs.getInt("offx", 0) * d).toInt()
        lp.y = (prefs.getInt("offy", 0) * d).toInt()
        runCatching { wm.updateViewLayout(v, lp) }
    }

    private fun applyVisibility() {
        hudBox?.visibility = if (prefs.getBoolean("hud_on", true)) View.VISIBLE else View.GONE
        controls?.visibility = if (prefs.getBoolean("move_on", true)) View.VISIBLE else View.GONE
    }

    // ================= HUD =================

    private fun addHud() {
        val tv = TextView(this).apply {
            setTextColor(Theme.TEXT)
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(7), dp(12), dp(7))
            setLineSpacing(0f, 1.1f)
        }
        hudText = tv
        val bar = View(this).apply {
            background = gradient(
                Theme.AMBER, Theme.VIOLET, 0f, GradientDrawable.Orientation.TOP_BOTTOM
            )
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            addView(bar, LinearLayout.LayoutParams(dp(3), LinearLayout.LayoutParams.MATCH_PARENT))
            addView(tv, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        hudBox = box
        val lp = overlayParams(false, Gravity.TOP or Gravity.START)
        hudLp = lp
        wm.addView(box, lp)
    }

    private fun applyHudStyle() {
        val box = hudBox ?: return
        val lp = hudLp ?: return
        val tv = hudText ?: return
        tv.textSize = Hud.textSizeSp(prefs)
        val a = prefs.getInt("hud_alpha", 75).coerceIn(20, 100) * 255 / 100
        box.background = rounded(Theme.BG.withAlpha(a), dp(12).toFloat(), Theme.STROKE.withAlpha(a), dp(1))
        val pos = prefs.getInt("hud_pos", 0)
        val bottom = pos == 2 || pos == 3
        val right = pos == 1 || pos == 3
        lp.gravity = (if (bottom) Gravity.BOTTOM else Gravity.TOP) or (if (right) Gravity.END else Gravity.START)
        lp.x = dp(8)
        lp.y = if (bottom) dp(16) else dp(24)
        runCatching { wm.updateViewLayout(box, lp) }
    }

    // ================= ปุ่มลอย (รูปเดิม) + แผงเลื่อนเป้า =================

    private fun nudge(dx: Int, dy: Int) {
        val st = prefs.getInt("step", 1).coerceAtLeast(1)
        val x = (prefs.getInt("offx", 0) + dx * st).coerceIn(-300, 300)
        val y = (prefs.getInt("offy", 0) + dy * st).coerceIn(-300, 300)
        prefs.edit().putInt("offx", x).putInt("offy", y).apply()
    }

    private fun resetOffset() {
        prefs.edit().putInt("offx", 0).putInt("offy", 0).apply()
    }

    private fun refreshHudBtn() {
        hudBtn?.setTextColor(if (prefs.getBoolean("hud_on", true)) Theme.AMBER else Theme.MUTED)
    }

    private fun addControls() {
        val size = dp(44)
        val margin = dp(2)

        fun btn(label: String, widthPx: Int = size, textSp: Float = 18f, color: Int = Color.WHITE,
                repeat: Boolean = true, action: () -> Unit): TextView {
            var repeater: Runnable? = null
            return TextView(this).apply {
                text = label
                textSize = textSp
                setTextColor(color)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(Theme.CARD_HI.withAlpha(0xE6), dp(12).toFloat(), Theme.STROKE, dp(1))
                layoutParams = LinearLayout.LayoutParams(widthPx, size).apply {
                    setMargins(margin, margin, margin, margin)
                }
                setOnTouchListener { _, ev ->
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> {
                            action()
                            if (repeat) {
                                val r = object : Runnable {
                                    override fun run() {
                                        action()
                                        handler.postDelayed(this, 50)
                                    }
                                }
                                repeater = r
                                handler.postDelayed(r, 400)
                            }
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            repeater?.let { handler.removeCallbacks(it) }
                            repeater = null
                        }
                    }
                    true
                }
            }
        }

        fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            views.forEach { addView(it) }
        }

        fun spacer(): View = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(size + 2 * margin, size)
        }

        val hb = btn("HUD", size * 3 / 2 + margin, 13f, Theme.AMBER, false) {
            prefs.edit().putBoolean("hud_on", !prefs.getBoolean("hud_on", true)).apply()
        }
        hudBtn = hb
        val stopBtn = btn("STOP", size * 3 / 2 + margin, 13f, Theme.DANGER, false) { stopSelf() }
        refreshHudBtn()

        val pad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(row(spacer(), btn("▲") { nudge(0, -1) }, spacer()))
            addView(row(btn("◀") { nudge(-1, 0) }, btn("●", repeat = false) { resetOffset() }, btn("▶") { nudge(1, 0) }))
            addView(row(spacer(), btn("▼") { nudge(0, 1) }, spacer()))
            addView(row(hb, stopBtn))
        }

        val lp = overlayParams(true, Gravity.TOP or Gravity.END)
        lp.x = dp(8)
        lp.y = dp(120)

        // ปุ่มลอยใช้รูปเดิม floating_avatar
        val toggle = ImageView(this).apply {
            setImageResource(R.drawable.floating_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#D6D2D1"))
                setStroke(dp(2), Theme.AMBER)
            }
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX
                        downY = ev.rawY
                        startX = lp.x
                        startY = lp.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.rawX - downX
                        val dy = ev.rawY - downY
                        if (moved || Math.abs(dx) > dp(10) || Math.abs(dy) > dp(10)) {
                            moved = true
                            // gravity = TOP|END ดังนั้นแกน x วัดจากขอบขวา
                            lp.x = startX - dx.toInt()
                            lp.y = startY + dy.toInt()
                            controls?.let { v -> runCatching { wm.updateViewLayout(v, lp) } }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            pad.visibility = if (pad.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                            controls?.let { v -> runCatching { wm.updateViewLayout(v, lp) } }
                        }
                    }
                }
                true
            }
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Theme.BG.withAlpha(0xA6), dp(18).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(4), dp(2), dp(4), dp(6))
            addView(toggle)
            addView(pad)
        }
        controls = box
        wm.addView(box, lp)
    }

    // ================= Foreground notification =================

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "ZEROPOINT", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("ZEROPOINT กำลังทำงาน")
            .setContentText("เป้าเล็งและ HUD เปิดอยู่")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "หยุด", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }
}
