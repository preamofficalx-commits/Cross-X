package com.zeropoint.hud

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator

/** วงแหวนวัดค่า 270° มีไล่สี และเลื่อนค่าแบบนุ่ม ๆ */
class RingGauge(ctx: Context) : View(ctx) {
    var title = ""
    private var valueText = "—"
    private var shown = 0f
    private var warn = false
    private var cA = Theme.AMBER
    private var cB = Theme.AMBER_DK
    private val rect = RectF()
    private var anim: ValueAnimator? = null

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Theme.STROKE
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val vp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.TEXT
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.MUTED
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.15f
    }

    fun setColors(a: Int, b: Int) {
        cA = a
        cB = b
        rebuild()
        invalidate()
    }

    fun set(pct: Int?, text: String, warn: Boolean = false) {
        valueText = text
        if (this.warn != warn) {
            this.warn = warn
            rebuild()
        }
        val target = (pct ?: 0).coerceIn(0, 100).toFloat()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shown, target).apply {
            duration = 450
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun rebuild() {
        if (width == 0) return
        val a = if (warn) Theme.DANGER else cA
        val b = if (warn) 0xFFFF8FA3.toInt() else cB
        arc.shader = SweepGradient(width / 2f, height / 2f, intArrayOf(a, b), floatArrayOf(0f, 0.75f))
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val sw = s * 0.085f
        track.strokeWidth = sw
        arc.strokeWidth = sw
        val cx = width / 2f
        val cy = height / 2f
        val r = s / 2f - sw
        rect.set(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rect, 135f, 270f, false, track)
        if (shown > 0.5f) {
            c.save()
            c.rotate(135f, cx, cy)
            c.drawArc(rect, 0f, 270f * shown / 100f, false, arc)
            c.restore()
        }
        vp.textSize = s * (if (valueText.length > 4) 0.19f else 0.25f)
        val vy = cy - (vp.ascent() + vp.descent()) / 2f - s * 0.03f
        c.drawText(valueText, cx, vy, vp)
        tp.textSize = s * 0.085f
        c.drawText(title, cx, cy + r * 0.80f + tp.textSize * 0.35f, tp)
    }
}

/** กราฟเส้นย้อนหลัง 60 วินาที */
class Sparkline(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val data = ArrayList<Int>()
    private val maxPts = 60
    var color = Theme.AMBER
        set(v) {
            field = v
            line.color = v
            rebuild()
        }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        color = Theme.AMBER
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint().apply {
        color = 0x14FFFFFF
        strokeWidth = 1f * d
    }
    private val path = Path()
    private val area = Path()

    fun push(v: Int?) {
        data.add((v ?: 0).coerceIn(0, 100))
        if (data.size > maxPts) data.removeAt(0)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    private fun rebuild() {
        if (height == 0) return
        fill.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(), color.withAlpha(110), color.withAlpha(0), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..3) c.drawLine(0f, h * i / 4f, w, h * i / 4f, grid)
        if (data.size < 2) return
        val step = w / (maxPts - 1)
        val x0 = w - (data.size - 1) * step
        path.reset()
        area.reset()
        data.forEachIndexed { i, v ->
            val x = x0 + i * step
            val y = h - (h - 4f * d) * v / 100f - 2f * d
            if (i == 0) {
                path.moveTo(x, y)
                area.moveTo(x, h)
                area.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                area.lineTo(x, y)
            }
        }
        area.lineTo(w, h)
        area.close()
        c.drawPath(area, fill)
        c.drawPath(path, line)
    }
}

/** พื้นหลังแอป: ดำม่วง + แสงม่วงมุมขวาบน + แสงอำพันมุมซ้ายล่าง */
class AuroraBackground(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Theme.BG)
        p.shader = RadialGradient(
            w * 0.95f, h * 0.05f, w * 0.9f,
            Theme.VIOLET.withAlpha(0x4A), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = RadialGradient(
            w * 0.05f, h * 0.98f, w * 0.85f,
            Theme.AMBER_DK.withAlpha(0x30), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }
}

/** ฉากจำลองสำหรับดูตัวอย่างเป้า: กริดจาง ๆ + เส้นกลางจอ */
class GridBackdrop(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val gridP = Paint().apply {
        color = 0x12FFFFFF
        strokeWidth = 1f * d
    }
    private val guideP = Paint().apply {
        color = Theme.AMBER.withAlpha(0x30)
        strokeWidth = 1f * d
    }

    init {
        background = rounded(Theme.BG2, 16f * d, Theme.STROKE, (1 * d).toInt())
        clipToOutline = true
        outlineProvider = ViewOutlineProvider.BACKGROUND
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val step = 24f * d
        var x = 0f
        while (x < w) {
            c.drawLine(x, 0f, x, h, gridP)
            x += step
        }
        var y = 0f
        while (y < h) {
            c.drawLine(0f, y, w, y, gridP)
            y += step
        }
        c.drawLine(w / 2f, 0f, w / 2f, h, guideP)
        c.drawLine(0f, h / 2f, w, h / 2f, guideP)
    }
}
