package com.zeropoint.hud

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_NOTIF = 1

class MainActivity : Activity() {

    private class Tile(val root: LinearLayout, val value: TextView, val sub: TextView)

    private val prefs by lazy { getSharedPreferences("zeropoint", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val startedAt = SystemClock.elapsedRealtime()

    private lateinit var content: FrameLayout
    private val pages = ArrayList<View>()
    private val navItems = ArrayList<TextView>()

    // header
    private lateinit var statusChip: TextView

    // dashboard
    private lateinit var startBtn: TextView
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var permCard: LinearLayout
    private lateinit var rowOverlay: View
    private lateinit var rowUsage: View
    private lateinit var rowNotif: View
    private lateinit var gCpu: RingGauge
    private lateinit var gGpu: RingGauge
    private lateinit var gBatt: RingGauge
    private lateinit var gRam: RingGauge
    private lateinit var tTemp: Tile
    private lateinit var tPower: Tile
    private lateinit var tPing: Tile
    private lateinit var tDisk: Tile
    private lateinit var tThermal: Tile
    private lateinit var tClock: Tile
    private lateinit var tApp: Tile
    private lateinit var spark: Sparkline
    private lateinit var hint: TextView

    // aim
    private lateinit var preview: CrosshairView
    private val syncers = ArrayList<() -> Unit>()
    private val resetters = ArrayList<() -> Unit>()

    // hud
    private lateinit var hudPreview: TextView

    private val prefL = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        if (::preview.isInitialized) preview.reload()
        if (::hudPreview.isInitialized) refreshHudPreview()
    }

    private val ticker = object : Runnable {
        override fun run() {
            refreshDash()
            refreshHero()
            refreshHudPreview()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Theme.BG
        window.navigationBarColor = Theme.BG2

        val root = FrameLayout(this)
        root.addView(AuroraBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(buildHeader())
        content = FrameLayout(this)
        col.addView(content, lp(MATCH, 0, 1f))

        pages.add(scroll(buildDash()))
        pages.add(scroll(buildAim()))
        pages.add(scroll(buildHudTab()))
        pages.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }

        col.addView(buildNav())
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        selectTab(0)
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(prefL)
        Stats.startPing()
        syncers.forEach { it() }
        refreshPerms()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        prefs.unregisterOnSharedPreferenceChangeListener(prefL)
        Stats.stopPing()
        super.onPause()
    }

    // ================= helpers =================

    private fun lp(
        w: Int, h: Int, weight: Float = 0f,
        l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0
    ): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight).apply { setMargins(l, t, r, b) }

    private fun tv(
        s: CharSequence, sp: Float, color: Int = Theme.TEXT,
        bold: Boolean = false, spacing: Float = 0f
    ): TextView = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        letterSpacing = spacing
    }

    private fun card(title: String? = null, sub: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Theme.CARD.withAlpha(0xDC), dp(22).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }
        if (title != null) {
            c.addView(tv(title, 11f, Theme.AMBER, true, 0.22f))
            if (sub != null) c.addView(tv(sub, 12f, Theme.MUTED).apply { setPadding(0, dp(3), 0, 0) })
        }
        return c
    }

    private fun addCard(parent: LinearLayout, c: View) {
        parent.addView(c, lp(MATCH, WRAP, 0f, dp(16), dp(7), dp(16), dp(7)))
    }

    private fun scroll(v: View): View = ScrollView(this).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        addView(v)
    }

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, dp(4), 0, dp(12))
    }

    private fun tintSwitch(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(Theme.AMBER.withAlpha(0xCC), Theme.STROKE))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Theme.MUTED))
    }

    private fun switchRow(
        title: String, key: String, def: Boolean, resettable: Boolean = false,
        onChange: (Boolean) -> Unit = {}
    ): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, 0)
        }
        val sw = Switch(this)
        tintSwitch(sw)
        var silent = false
        fun sync() {
            silent = true
            sw.isChecked = prefs.getBoolean(key, def)
            silent = false
        }
        sw.setOnCheckedChangeListener { _, c ->
            if (silent) return@setOnCheckedChangeListener
            prefs.edit().putBoolean(key, c).apply()
            onChange(c)
        }
        sync()
        syncers.add { sync() }
        if (resettable) resetters.add {
            prefs.edit().putBoolean(key, def).apply()
            sync()
        }
        row.addView(tv(title, 14f), lp(0, WRAP, 1f))
        row.addView(sw)
        return row
    }

    private fun slider(
        parent: LinearLayout, title: String, key: String,
        lo: Int, hi: Int, def: Int, unit: String = "", resettable: Boolean = true
    ) {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        val vtxt = tv("", 13f, Theme.AMBER, true)
        head.addView(tv(title, 13f), lp(0, WRAP, 1f))
        head.addView(vtxt)

        val sb = SeekBar(this).apply {
            max = hi - lo
            progressTintList = ColorStateList.valueOf(Theme.AMBER)
            thumbTintList = ColorStateList.valueOf(Theme.AMBER)
            progressBackgroundTintList = ColorStateList.valueOf(Theme.STROKE)
        }
        var silent = false
        fun sync() {
            silent = true
            val v = prefs.getInt(key, def)
            sb.progress = v - lo
            vtxt.text = "$v$unit"
            silent = false
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (silent) return
                val n = p + lo
                vtxt.text = "$n$unit"
                prefs.edit().putInt(key, n).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        sync()
        syncers.add { sync() }
        if (resettable) resetters.add {
            prefs.edit().putInt(key, def).apply()
            sync()
        }
        parent.addView(head)
        parent.addView(sb)
    }

    private fun segmented(options: List<String>, key: String, def: Int): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        val views = ArrayList<TextView>()
        fun restyle() {
            val sel = prefs.getInt(key, def)
            views.forEachIndexed { i, t ->
                val on = i == sel
                t.background = if (on) gradient(Theme.AMBER, Theme.AMBER_DK, dp(12).toFloat())
                else rounded(Theme.BG.withAlpha(0xAA), dp(12).toFloat(), Theme.STROKE, dp(1))
                t.setTextColor(if (on) Color.BLACK else Theme.MUTED)
            }
        }
        options.forEachIndexed { i, name ->
            val t = TextView(this).apply {
                text = name
                textSize = 12f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(4), dp(11), dp(4), dp(11))
                setOnClickListener {
                    prefs.edit().putInt(key, i).apply()
                    restyle()
                }
            }
            views.add(t)
            row.addView(t, lp(0, WRAP, 1f, dp(3), 0, dp(3), 0))
        }
        syncers.add { restyle() }
        restyle()
        return row
    }

    // ================= header / nav =================

    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(8))
        }
        val avatar = ImageView(this).apply {
            setImageResource(R.drawable.floating_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#D6D2D1"))
                setStroke(dp(2), Theme.AMBER)
            }
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            clipToOutline = true
        }
        row.addView(avatar, lp(dp(46), dp(46), 0f, 0, 0, dp(12), 0))

        val title = SpannableStringBuilder("ZERO")
        val s = title.length
        title.append("POINT")
        title.setSpan(ForegroundColorSpan(Theme.AMBER), s, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        names.addView(tv(title, 24f, Theme.TEXT, true, 0.12f))
        names.addView(tv("AIM  ·  HUD  ·  OVERLAY", 9f, Theme.MUTED, true, 0.3f))
        row.addView(names, lp(0, WRAP, 1f))

        statusChip = tv("", 11f, Theme.MUTED, true, 0.08f).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        row.addView(statusChip)
        return row
    }

    private fun buildNav(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Theme.CARD.withAlpha(0xF0), dp(28).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        listOf("หน้าหลัก", "เป้าเล็ง", "HUD").forEachIndexed { i, n ->
            val t = tv(n, 13f, Theme.MUTED, true, 0.04f).apply {
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(12), dp(4), dp(12))
                setOnClickListener { selectTab(i) }
            }
            navItems.add(t)
            bar.addView(t, lp(0, WRAP, 1f))
        }
        val wrap = FrameLayout(this)
        wrap.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(6), dp(16), dp(12)) })
        return wrap
    }

    private fun selectTab(i: Int) {
        pages.forEachIndexed { idx, v -> v.visibility = if (idx == i) View.VISIBLE else View.GONE }
        navItems.forEachIndexed { idx, t ->
            val on = idx == i
            t.setTextColor(if (on) Color.BLACK else Theme.MUTED)
            t.background = if (on) gradient(Theme.AMBER, Theme.AMBER_DK, dp(22).toFloat()) else null
        }
    }

    // ================= tab 1: หน้าหลัก =================

    private fun gauge(title: String, a: Int, b: Int): RingGauge = RingGauge(this).apply {
        this.title = title
        setColors(a, b)
    }

    private fun tile(title: String): Tile {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Theme.BG.withAlpha(0xB0), dp(14).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        r.addView(tv(title, 9f, Theme.MUTED, true, 0.18f))
        val v = tv("—", 17f, Theme.TEXT, true).apply { setPadding(0, dp(2), 0, 0) }
        r.addView(v)
        val s = tv("", 10f, Theme.MUTED).apply { visibility = View.GONE }
        r.addView(s)
        return Tile(r, v, s)
    }

    private fun setTile(t: Tile, value: String, color: Int = Theme.TEXT, sub: String? = null) {
        t.value.text = value
        t.value.setTextColor(color)
        if (sub.isNullOrEmpty()) {
            t.sub.visibility = View.GONE
        } else {
            t.sub.text = sub
            t.sub.visibility = View.VISIBLE
        }
    }

    private fun row2(a: View, b: View, hDp: Int = 0): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        val h = if (hDp > 0) dp(hDp) else WRAP
        addView(a, lp(0, h, 1f, 0, 0, dp(5), 0))
        addView(b, lp(0, h, 1f, dp(5), 0, 0, 0))
    }

    private fun permRow(title: String, desc: String, onClick: () -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Theme.BG.withAlpha(0xB0), dp(14).toFloat(), Theme.AMBER.withAlpha(0x70), dp(1))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { onClick() }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(title, 14f, Theme.TEXT, true))
        col.addView(tv(desc, 11f, Theme.MUTED))
        r.addView(col, lp(0, WRAP, 1f))
        r.addView(tv("อนุญาต ›", 13f, Theme.AMBER, true))
        return r
    }

    private fun buildDash(): View {
        val col = page()

        // hero
        val hero = card()
        heroTitle = tv("", 20f, Theme.TEXT, true)
        heroSub = tv("", 12f, Theme.MUTED).apply { setPadding(0, dp(3), 0, 0) }
        hero.addView(heroTitle)
        hero.addView(heroSub)
        startBtn = TextView(this).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(17), dp(16), dp(17))
            setOnClickListener { toggleOverlay() }
        }
        hero.addView(startBtn, lp(MATCH, WRAP, 0f, 0, dp(16), 0, 0))
        addCard(col, hero)

        // permissions
        permCard = card("การอนุญาตที่ต้องใช้", "แตะเพื่อเปิดหน้าตั้งค่าของระบบ")
        rowOverlay = permRow("แสดงทับแอปอื่น", "จำเป็น — ใช้วางเป้ากับ HUD บนจอเกม") { openOverlaySettings() }
        rowUsage = permRow("เข้าถึงข้อมูลการใช้งาน", "ใช้บอกว่าตอนนี้เปิดแอป/เกมอะไรอยู่") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        rowNotif = permRow("การแจ้งเตือน", "ใช้แสดงปุ่มหยุดบนแถบแจ้งเตือน") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
        }
        for (v in listOf(rowOverlay, rowUsage, rowNotif)) {
            permCard.addView(v, lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        }
        addCard(col, permCard)

        // gauges
        gCpu = gauge("CPU", Theme.AMBER, Theme.AMBER_DK)
        gGpu = gauge("GPU", Theme.VIOLET, Theme.ICE)
        gBatt = gauge("BATT", Theme.GREEN, Theme.ICE)
        gRam = gauge("RAM", Theme.ICE, Theme.VIOLET)
        val g = card("LIVE", "ข้อมูลเครื่องแบบสด อัปเดตทุกวินาที")
        g.addView(row2(gCpu, gGpu, 128), lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        g.addView(row2(gBatt, gRam, 128), lp(MATCH, WRAP, 0f, 0, dp(4), 0, 0))
        hint = tv("", 11f, Theme.MUTED).apply {
            setPadding(0, dp(10), 0, 0)
            visibility = View.GONE
        }
        g.addView(hint)
        addCard(col, g)

        // tiles
        tTemp = tile("TEMP")
        tPower = tile("POWER")
        tPing = tile("PING")
        tDisk = tile("DISK")
        tThermal = tile("THERMAL")
        tClock = tile("CLOCK")
        tApp = tile("FOREGROUND APP")
        val t = card("SYSTEM")
        t.addView(row2(tTemp.root, tPower.root), lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        t.addView(row2(tPing.root, tDisk.root), lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        t.addView(row2(tThermal.root, tClock.root), lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        t.addView(tApp.root, lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        addCard(col, t)

        // history
        spark = Sparkline(this)
        val h = card("CPU 60 วินาทีล่าสุด")
        h.addView(spark, lp(MATCH, dp(90), 0f, 0, dp(10), 0, 0))
        addCard(col, h)

        return col
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
        } else if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "ต้องอนุญาตแสดงทับแอปอื่นก่อน", Toast.LENGTH_LONG).show()
            openOverlaySettings()
        } else {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        handler.postDelayed({ refreshHero() }, 400)
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        refreshPerms()
    }

    private fun refreshPerms() {
        val overlayOk = Settings.canDrawOverlays(this)
        val usageOk = Stats.hasUsageAccess(this)
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        rowOverlay.visibility = if (overlayOk) View.GONE else View.VISIBLE
        rowUsage.visibility = if (usageOk) View.GONE else View.VISIBLE
        rowNotif.visibility = if (notifOk) View.GONE else View.VISIBLE
        permCard.visibility = if (overlayOk && usageOk && notifOk) View.GONE else View.VISIBLE
    }

    private fun refreshHero() {
        val on = OverlayService.running
        if (on) {
            heroTitle.text = "กำลังทำงาน"
            heroTitle.setTextColor(Theme.GREEN)
            heroSub.text = "เป้ากับ HUD กำลังลอยทับหน้าจอ สลับไปเปิดเกมได้เลย"
            startBtn.text = "■   หยุด"
            startBtn.setTextColor(Color.WHITE)
            startBtn.background = gradient(Theme.DANGER, 0xFFD62F8A.toInt(), dp(18).toFloat())
        } else {
            heroTitle.text = "พร้อมใช้งาน"
            heroTitle.setTextColor(Theme.TEXT)
            heroSub.text = "กดเริ่ม แล้วเปิดเกม — ใช้ปุ่มลอยขยับเป้าให้ตรงจุด"
            startBtn.text = "▶   เริ่มเป้าเล็ง"
            startBtn.setTextColor(Color.BLACK)
            startBtn.background = gradient(Theme.AMBER, Theme.AMBER_DK, dp(18).toFloat())
        }
        statusChip.text = if (on) "● ON" else "● OFF"
        val cc = if (on) Theme.GREEN else Theme.MUTED
        statusChip.setTextColor(cc)
        statusChip.background = rounded(Theme.CARD, dp(14).toFloat(), cc, dp(1))
    }

    private fun refreshDash() {
        val b = Stats.battery(this)
        gBatt.set(
            if (b.percent >= 0) b.percent else null,
            if (b.percent >= 0) "${b.percent}%" + (if (b.charging) "⚡" else "") else "—",
            b.percent in 0..15
        )
        val cpu = Stats.cpuPercent()
        gCpu.set(cpu, cpu?.let { "$it%" } ?: "N/A", (cpu ?: 0) >= 85)
        spark.push(cpu)
        val gpu = Stats.gpuPercent()
        gGpu.set(gpu, gpu?.let { (if (Stats.gpuEstimated) "~" else "") + "$it%" } ?: "N/A", (gpu ?: 0) >= 85)
        val m = Stats.memory(this)
        gRam.set(m.pct, "${m.pct}%", m.pct >= 90)

        setTile(tTemp, String.format(Locale.US, "%.1f°C", b.tempC), tempColor(b.tempC))
        setTile(
            tPower,
            b.powerW?.let { String.format(Locale.US, "%.1f W", it) } ?: "—",
            Theme.TEXT,
            if (b.charging) "กำลังชาร์จ" else if (b.powerW != null) "กำลังใช้พลังงาน" else null
        )
        val ping = Stats.pingMs
        setTile(tPing, if (ping >= 0) "$ping ms" else "—", pingColor(ping))
        val dsk = Stats.diskPercent()
        setTile(tDisk, "$dsk%", Theme.TEXT, "พื้นที่ที่ใช้ไป")
        setTile(tThermal, Stats.thermalLabel(this) ?: "—")
        setTile(tClock, java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date()))

        if (Stats.hasUsageAccess(this)) {
            val fg = Stats.foreground(this)
            setTile(tApp, fg?.label ?: "—", Theme.TEXT, fg?.pkg)
        } else {
            setTile(tApp, "ยังไม่ได้อนุญาต", Theme.AMBER, "เปิดสิทธิ์ 'เข้าถึงข้อมูลการใช้งาน' เพื่อดูชื่อเกม")
        }

        val notes = ArrayList<String>()
        if (gpu == null) notes.add("GPU: เครื่องนี้ไม่เปิดให้แอปอ่านค่า (Android จำกัดสิทธิ์)")
        else if (Stats.gpuEstimated) notes.add("GPU: ค่า ~ คือประเมินจากคล็อก ไม่ใช่โหลดจริง")
        if (cpu == null) notes.add("CPU: เครื่องนี้ไม่เปิดให้แอปอ่านค่า")
        hint.text = notes.joinToString("\n")
        hint.visibility = if (notes.isEmpty()) View.GONE else View.VISIBLE
    }

    // ================= tab 2: เป้าเล็ง =================

    private val presets = listOf(
        Triple("ขาว", 0, 0), Triple("แดง", 0, 100), Triple("ส้ม", 28, 100), Triple("เหลือง", 50, 100),
        Triple("เขียว", 140, 100), Triple("ฟ้า", 187, 100), Triple("ม่วง", 265, 70), Triple("ชมพู", 325, 80)
    )

    private fun buildStyleStrip(): View {
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("CROSS", "DOT", "CIRCLE", "RING", "T-SHAPE", "CHEVRON", "HYBRID", "BRACKET")
        val boxes = ArrayList<FrameLayout>()
        fun restyle() {
            val sel = prefs.getInt("style", 0)
            boxes.forEachIndexed { i, b ->
                val on = i == sel
                b.background = rounded(
                    if (on) Theme.AMBER.withAlpha(0x26) else Theme.BG.withAlpha(0xB0),
                    dp(16).toFloat(), if (on) Theme.AMBER else Theme.STROKE, dp(if (on) 2 else 1)
                )
            }
        }
        names.forEachIndexed { i, n ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            val box = FrameLayout(this)
            box.addView(CrosshairView(this, i, true), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
            box.setOnClickListener {
                prefs.edit().putInt("style", i).apply()
                restyle()
            }
            boxes.add(box)
            cell.addView(box, lp(dp(66), dp(66)))
            cell.addView(tv(n, 9f, Theme.MUTED, true, 0.1f), lp(WRAP, WRAP, 0f, 0, dp(6), 0, 0))
            row.addView(cell, lp(WRAP, WRAP, 0f, 0, 0, dp(10), 0))
        }
        syncers.add { restyle() }
        restyle()
        hs.addView(row)
        return hs
    }

    private fun buildSwatches(): View {
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dots = ArrayList<View>()
        fun restyle() {
            val h = prefs.getInt("hue", 0)
            val s = prefs.getInt("sat", 100)
            presets.forEachIndexed { i, p ->
                val on = p.second == h && p.third == s
                val col = Color.HSVToColor(floatArrayOf(p.second.toFloat(), p.third / 100f, 1f))
                dots[i].background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(col)
                    setStroke(dp(if (on) 3 else 1), if (on) Color.WHITE else Theme.STROKE)
                }
            }
        }
        presets.forEach { p ->
            val v = View(this).apply {
                setOnClickListener {
                    prefs.edit().putInt("hue", p.second).putInt("sat", p.third).apply()
                    syncers.forEach { it() }
                }
            }
            dots.add(v)
            row.addView(v, lp(dp(36), dp(36), 0f, 0, 0, dp(10), 0))
        }
        syncers.add { restyle() }
        restyle()
        hs.addView(row)
        return hs
    }

    private fun buildAim(): View {
        val col = page()

        val pv = card("PREVIEW", "ตัวอย่างเป้าตามที่ตั้งค่า")
        val backdrop = GridBackdrop(this)
        val box = FrameLayout(this)
        box.addView(backdrop, FrameLayout.LayoutParams(MATCH, MATCH))
        preview = CrosshairView(this)
        box.addView(preview, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        pv.addView(box, lp(MATCH, dp(170), 0f, 0, dp(12), 0, 0))
        addCard(col, pv)

        val st = card("STYLE", "เลือกรูปแบบเป้า 8 แบบ")
        st.addView(buildStyleStrip(), lp(MATCH, WRAP, 0f, 0, dp(14), 0, 0))
        addCard(col, st)

        val cl = card("COLOR")
        cl.addView(buildSwatches(), lp(MATCH, WRAP, 0f, 0, dp(12), 0, 0))
        slider(cl, "เฉดสี", "hue", 0, 360, 0)
        slider(cl, "ความเข้มสี (0 = ขาว)", "sat", 0, 100, 100)
        slider(cl, "ความโปร่งใส", "alpha", 10, 100, 100, "%")
        addCard(col, cl)

        val sh = card("SHAPE")
        slider(sh, "ขนาด", "size", 20, 160, 48, "dp")
        slider(sh, "ความหนา", "thick", 1, 8, 2, "dp")
        slider(sh, "ช่องว่างกลางเป้า", "gap", 0, 30, 6, "dp")
        sh.addView(switchRow("ขอบดำ (อ่านง่ายบนพื้นสว่าง)", "outline", true, true))
        sh.addView(switchRow("จุดกลางเป้า", "dot", true, true))
        addCard(col, sh)

        val ps = card("POSITION", "ปรับตำแหน่งเป้า หรือใช้ปุ่มลอยตอนเล่น")
        slider(ps, "เลื่อนซ้าย (-) / ขวา (+)", "offx", -300, 300, 0)
        slider(ps, "เลื่อนขึ้น (-) / ลง (+)", "offy", -300, 300, 0)
        slider(ps, "ระยะต่อการแตะปุ่มลอย", "step", 1, 5, 1, "dp")
        ps.addView(switchRow("แสดงปุ่มลอย (รูปปุ่ม + ลูกศร)", "move_on", true))
        val reset = tv("รีเซ็ตเป้าทั้งหมด", 14f, Theme.TEXT, true).apply {
            gravity = Gravity.CENTER
            background = rounded(Theme.CARD_HI, dp(16).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener {
                prefs.edit().putInt("style", 0).apply()
                resetters.forEach { it() }
                syncers.forEach { it() }
            }
        }
        ps.addView(reset, lp(MATCH, WRAP, 0f, 0, dp(18), 0, 0))
        addCard(col, ps)
        return col
    }

    // ================= tab 3: HUD =================

    private fun hudBg() = rounded(
        Theme.BG.withAlpha(prefs.getInt("hud_alpha", 75).coerceIn(20, 100) * 255 / 100),
        dp(12).toFloat(), Theme.STROKE, dp(1)
    )

    private fun refreshHudPreview() {
        hudPreview.textSize = Hud.textSizeSp(prefs)
        hudPreview.background = hudBg()
        hudPreview.text = Hud.build(this, prefs, startedAt)
    }

    private fun buildHudTab(): View {
        val col = page()

        val pv = card("PREVIEW", "หน้าตา HUD ที่จะลอยบนจอเกม")
        hudPreview = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            setTextColor(Theme.TEXT)
            setPadding(dp(12), dp(9), dp(14), dp(9))
            setLineSpacing(0f, 1.1f)
        }
        val holder = FrameLayout(this).apply {
            background = rounded(Theme.BG2, dp(16).toFloat(), Theme.STROKE, dp(1))
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        holder.addView(hudPreview, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.TOP))
        pv.addView(holder, lp(MATCH, WRAP, 0f, 0, dp(12), 0, 0))
        addCard(col, pv)

        val sw = card("METRICS", "เลือกว่าจะโชว์อะไรบ้าง")
        sw.addView(switchRow("แสดง HUD", "hud_on", true))
        sw.addView(switchRow("แอปที่ใช้อยู่", "hud_app", true))
        sw.addView(switchRow("แบตเตอรี่ + อุณหภูมิ + วัตต์", "hud_bat", true))
        sw.addView(switchRow("CPU", "hud_cpu", true))
        sw.addView(switchRow("GPU", "hud_gpu", true))
        sw.addView(switchRow("RAM", "hud_ram", true))
        sw.addView(switchRow("Ping", "hud_ping", true))
        sw.addView(switchRow("นาฬิกา + เวลาที่เปิดเป้า", "hud_time", true))
        addCard(col, sw)

        val ly = card("LAYOUT")
        ly.addView(tv("รูปแบบ", 13f).apply { setPadding(0, dp(12), 0, 0) })
        ly.addView(segmented(listOf("เต็ม (หลายบรรทัด)", "กะทัดรัด (บรรทัดเดียว)"), "hud_mode", 0))
        ly.addView(tv("ตำแหน่ง", 13f).apply { setPadding(0, dp(14), 0, 0) })
        ly.addView(segmented(listOf("ซ้ายบน", "ขวาบน", "ซ้ายล่าง", "ขวาล่าง"), "hud_pos", 0))
        ly.addView(tv("ขนาดตัวอักษร", 13f).apply { setPadding(0, dp(14), 0, 0) })
        ly.addView(segmented(listOf("เล็ก", "กลาง", "ใหญ่"), "hud_size", 1))
        slider(ly, "ความโปร่งใสพื้นหลัง", "hud_alpha", 20, 100, 75, "%", false)
        addCard(col, ly)

        return col
    }
}
