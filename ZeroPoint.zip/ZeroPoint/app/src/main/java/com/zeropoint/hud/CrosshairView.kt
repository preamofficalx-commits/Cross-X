package com.zeropoint.hud

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * เป้าเล็ง 8 แบบ: 0 กากบาท, 1 จุด, 2 วงกลม, 3 วงแหวน+จุด, 4 ตัว T, 5 หัวลูกศร, 6 ไฮบริด, 7 วงเล็บมุม
 * อ่านค่าจาก SharedPreferences "zeropoint"
 * tile = true → วาดแบบย่อสีขาวสำหรับปุ่มเลือกแบบ (ไม่สนค่าที่ผู้ใช้ตั้ง)
 */
class CrosshairView(
    context: Context,
    private val styleOverride: Int? = null,
    private val tile: Boolean = false
) : View(context) {

    private val d = resources.displayMetrics.density
    private val prefs = context.getSharedPreferences("zeropoint", Context.MODE_PRIVATE)

    private var style = 0
    private var sizePx = (48 * d).toInt()
    private var len = 20 * d
    private var gap = 6 * d
    private var thick = 2 * d
    private var outlineW = 1.2f * d
    private var showOutline = true
    private var showDot = true
    private var mainColor = Color.RED
    private var outlineColor = Color.BLACK

    private val strokeMain = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val strokeOut = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillMain = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val fillOut = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()

    init {
        reload()
    }

    fun reload() {
        style = styleOverride ?: prefs.getInt("style", 0)
        val sizeDp: Int
        val thickDp: Int
        val gapDp: Int
        val alphaPct: Int
        if (tile) {
            sizeDp = 40
            thickDp = 2
            gapDp = 5
            alphaPct = 100
            showOutline = false
            showDot = false
            mainColor = Color.WHITE
        } else {
            sizeDp = prefs.getInt("size", 48)
            thickDp = prefs.getInt("thick", 2)
            gapDp = prefs.getInt("gap", 6)
            alphaPct = prefs.getInt("alpha", 100)
            showOutline = prefs.getBoolean("outline", true)
            showDot = prefs.getBoolean("dot", true)
            val hue = prefs.getInt("hue", 0)
            val sat = prefs.getInt("sat", 100)
            mainColor = Color.HSVToColor(floatArrayOf(hue.toFloat(), sat / 100f, 1f))
        }
        val a = (alphaPct.coerceIn(10, 100) * 255 / 100)
        mainColor = mainColor.withAlpha(a)
        outlineColor = Color.BLACK.withAlpha(a * 85 / 100)

        sizePx = (sizeDp * d).toInt()
        len = sizeDp / 2f * d - 3f * d
        gap = minOf(gapDp * d, len * 0.85f)
        thick = thickDp * d
        outlineW = 1.2f * d

        strokeMain.color = mainColor
        strokeMain.strokeWidth = thick
        strokeOut.color = outlineColor
        strokeOut.strokeWidth = thick + 2f * outlineW
        fillMain.color = mainColor
        fillOut.color = outlineColor
        requestLayout()
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(sizePx, sizePx)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        if (showOutline) {
            strokes(c, strokeOut, cx, cy)
            dot(c, fillOut, cx, cy, outlineW)
        }
        strokes(c, strokeMain, cx, cy)
        dot(c, fillMain, cx, cy, 0f)
    }

    private fun dot(c: Canvas, p: Paint, cx: Float, cy: Float, extra: Float) {
        val always = style == 1 || style == 3 || style == 6
        if (!always && !showDot) return
        var r = maxOf(1.4f * d, thick * 0.75f)
        if (style == 1) r *= 2.2f
        c.drawCircle(cx, cy, r + extra, p)
    }

    private fun cross(c: Canvas, p: Paint, cx: Float, cy: Float, top: Boolean) {
        c.drawLine(cx - len, cy, cx - gap, cy, p)
        c.drawLine(cx + gap, cy, cx + len, cy, p)
        if (top) c.drawLine(cx, cy - len, cx, cy - gap, p)
        c.drawLine(cx, cy + gap, cx, cy + len, p)
    }

    private fun strokes(c: Canvas, p: Paint, cx: Float, cy: Float) {
        when (style) {
            0 -> cross(c, p, cx, cy, true)
            2 -> c.drawCircle(cx, cy, len * 0.8f, p)
            3 -> c.drawCircle(cx, cy, len * 0.55f, p)
            4 -> cross(c, p, cx, cy, false)
            5 -> {
                val w = len * 0.55f
                path.reset()
                path.moveTo(cx - w, cy + w)
                path.lineTo(cx, cy)
                path.lineTo(cx + w, cy + w)
                c.drawPath(path, p)
            }
            6 -> {
                val rr = gap + len * 0.25f
                c.drawCircle(cx, cy, rr, p)
                c.drawLine(cx - len, cy, cx - rr, cy, p)
                c.drawLine(cx + rr, cy, cx + len, cy, p)
                c.drawLine(cx, cy - len, cx, cy - rr, p)
                c.drawLine(cx, cy + rr, cx, cy + len, p)
            }
            7 -> {
                val b = len * 0.8f
                val a = len * 0.35f
                for (sx in intArrayOf(-1, 1)) {
                    for (sy in intArrayOf(-1, 1)) {
                        val px = cx + sx * b
                        val py = cy + sy * b
                        c.drawLine(px, py, cx + sx * (b - a), py, p)
                        c.drawLine(px, py, px, cy + sy * (b - a), p)
                    }
                }
            }
            else -> {}
        }
    }
}
