package com.vanta.aim

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_NOTIF = 1

class MainActivity : Activity() {

    private class Tile(val root: LinearLayout, val value: TextView, val sub: TextView)

    private val prefs: SharedPreferences by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val startedAt = SystemClock.elapsedRealtime()
    private val clockFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    private lateinit var content: FrameLayout
    private val pages = ArrayList<View>()
    private val navTabs = ArrayList<NavTab>()

    // header
    private lateinit var statusChip: TextView

    // home
    private lateinit var orb: PowerOrb
    private lateinit var startBtn: TextView
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var permCard: LinearLayout
    private lateinit var rowOverlay: View
    private lateinit var rowUsage: View
    private lateinit var rowNotif: View
    private lateinit var gCpu: RingGauge
    private lateinit var gGpu: RingGauge
    private lateinit var gBatt: RingGauge
    private lateinit var gRam: RingGauge
    private lateinit var hint: TextView
    private lateinit var fgIcon: ImageView
    private lateinit var fgName: TextView
    private lateinit var fgPkg: TextView
    private lateinit var tTemp: Tile
    private lateinit var tPower: Tile
    private lateinit var tPing: Tile
    private lateinit var tNet: Tile
    private lateinit var tDisplay: Tile
    private lateinit var tDisk: Tile
    private lateinit var tThermal: Tile
    private lateinit var tEta: Tile
    private lateinit var coreBars: CoreBars
    private lateinit var coreInfo: TextView
    private lateinit var spCpu: Sparkline
    private lateinit var spGpu: Sparkline
    private lateinit var dDevice: TextView
    private lateinit var dSoc: TextView
    private lateinit var dGpu: TextView
    private lateinit var dAndroid: TextView
    private lateinit var dRam: TextView
    private lateinit var dScreen: TextView
    private var iconPkg: String? = null

    // aim
    private lateinit var preview: CrosshairView
    private val syncers = ArrayList<() -> Unit>()
    private val resetters = ArrayList<() -> Unit>()

    // hud
    private lateinit var hudPreview: TextView

    private val prefL = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        if (::preview.isInitialized) preview.reload()
        if (::hudPreview.isInitialized) refreshHudPreview()
    }

    private val ticker = object : Runnable {
        override fun run() {
            refreshDash()
            refreshHero()
            refreshHudPreview()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Theme.BG
        window.navigationBarColor = Theme.BG2

        val root = FrameLayout(this)
        root.addView(AuroraBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(buildHeader())
        content = FrameLayout(this)
        col.addView(content, lp(MATCH, 0, 1f))

        pages.add(scroll(buildHome()))
        pages.add(scroll(buildAim()))
        pages.add(scroll(buildHudTab()))
        for (p in pages) content.addView(p, FrameLayout.LayoutParams(MATCH, MATCH))

        col.addView(buildNav())
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        selectTab(0)
        Stats.loadGpuName()
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(prefL)
        Stats.startPing()
        for (s in syncers) s()
        refreshPerms()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        prefs.unregisterOnSharedPreferenceChangeListener(prefL)
        Stats.stopPing()
        super.onPause()
    }

    // ================= helpers =================

    private fun lp(
        w: Int, h: Int, weight: Float = 0f,
        l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0
    ): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(l, t, r, b)
        return p
    }

    private fun tv(
        s: CharSequence, sp: Float, color: Int = Theme.TEXT,
        bold: Boolean = false, spacing: Float = 0f
    ): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        t.letterSpacing = spacing
        return t
    }

    private fun header(title: String, sub: String?): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val bar = View(this)
        bar.background = gradient(Theme.AMBER, Theme.EMBER, dp(2).toFloat(), GradientDrawable.Orientation.TOP_BOTTOM)
        row.addView(bar, lp(dp(3), dp(13), 0f, 0, 0, dp(8), 0))
        row.addView(tv(title, 11f, Theme.AMBER, true, 0.22f))
        col.addView(row)
        if (sub != null) {
            val s = tv(sub, 12f, Theme.MUTED)
            s.setPadding(0, dp(4), 0, 0)
            col.addView(s)
        }
        return col
    }

    private fun card(title: String? = null, sub: String? = null): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = glass(dp(24).toFloat(), dp(1))
        c.setPadding(dp(18), dp(16), dp(18), dp(18))
        if (title != null) c.addView(header(title, sub))
        return c
    }

    private fun addCard(parent: LinearLayout, c: View) {
        parent.addView(c, lp(MATCH, WRAP, 0f, dp(16), dp(7), dp(16), dp(7)))
    }

    private fun scroll(v: View): View {
        val s = ScrollView(this)
        s.isVerticalScrollBarEnabled = false
        s.overScrollMode = View.OVER_SCROLL_NEVER
        s.addView(v)
        return s
    }

    private fun page(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(0, dp(4), 0, dp(14))
        return p
    }

    private fun tintSwitch(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(Theme.AMBER.withAlpha(0xCC), Theme.STROKE))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Theme.MUTED))
    }

    private fun switchRow(
        title: String, key: String, def: Boolean, resettable: Boolean = false
    ): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(14), 0, 0)
        val sw = Switch(this)
        tintSwitch(sw)
        var silent = false
        val sync = {
            silent = true
            sw.isChecked = prefs.getBoolean(key, def)
            silent = false
        }
        sw.setOnCheckedChangeListener { _, c ->
            if (!silent) prefs.edit().putBoolean(key, c).apply()
        }
        sync()
        syncers.add(sync)
        if (resettable) {
            resetters.add {
                prefs.edit().putBoolean(key, def).apply()
                sync()
            }
        }
        row.addView(tv(title, 14f), lp(0, WRAP, 1f))
        row.addView(sw)
        return row
    }

    private fun slider(
        parent: LinearLayout, title: String, key: String,
        lo: Int, hi: Int, def: Int, unit: String = "", resettable: Boolean = true
    ) {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.setPadding(0, dp(14), 0, 0)
        val vtxt = tv("", 13f, Theme.AMBER, true)
        head.addView(tv(title, 13f), lp(0, WRAP, 1f))
        head.addView(vtxt)

        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progressTintList = ColorStateList.valueOf(Theme.AMBER)
        sb.thumbTintList = ColorStateList.valueOf(Theme.AMBER)
        sb.progressBackgroundTintList = ColorStateList.valueOf(Theme.STROKE)
        var silent = false
        val sync = {
            silent = true
            val v = prefs.getInt(key, def)
            sb.progress = v - lo
            vtxt.text = "$v$unit"
            silent = false
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (silent) return
                val n = p + lo
                vtxt.text = "$n$unit"
                prefs.edit().putInt(key, n).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        sync()
        syncers.add(sync)
        if (resettable) {
            resetters.add {
                prefs.edit().putInt(key, def).apply()
                sync()
            }
        }
        parent.addView(head)
        parent.addView(sb)
    }

    private fun segmented(options: List<String>, key: String, def: Int): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(8), 0, 0)
        val views = ArrayList<TextView>()
        val restyle = {
            val sel = prefs.getInt(key, def)
            for (i in views.indices) {
                val t = views[i]
                val on = i == sel
                t.background = if (on) gradient(Theme.AMBER, Theme.EMBER, dp(13).toFloat())
                else rounded(Theme.BG.withAlpha(0xAA), dp(13).toFloat(), Theme.STROKE, dp(1))
                t.setTextColor(if (on) Color.BLACK else Theme.MUTED)
            }
        }
        for (i in options.indices) {
            val t = TextView(this)
            t.text = options[i]
            t.textSize = 12f
            t.gravity = Gravity.CENTER
            t.typeface = Typeface.DEFAULT_BOLD
            t.setPadding(dp(4), dp(11), dp(4), dp(11))
            t.setOnClickListener {
                prefs.edit().putInt(key, i).apply()
                restyle()
            }
            views.add(t)
            row.addView(t, lp(0, WRAP, 1f, dp(3), 0, dp(3), 0))
        }
        syncers.add(restyle)
        restyle()
        return row
    }

    private fun avatar(sizeDp: Int): ImageView {
        val a = ImageView(this)
        a.setImageResource(R.drawable.floating_avatar)
        a.scaleType = ImageView.ScaleType.CENTER_CROP
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#D6D2D1"))
        bg.setStroke(dp(2), Theme.AMBER)
        a.background = bg
        a.outlineProvider = ViewOutlineProvider.BACKGROUND
        a.clipToOutline = true
        a.layoutParams = lp(dp(sizeDp), dp(sizeDp))
        return a
    }

    // ================= header / nav =================

    private fun buildHeader(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(20), dp(14), dp(20), dp(8))

        val av = avatar(44)
        av.layoutParams = lp(dp(44), dp(44), 0f, 0, 0, dp(12), 0)
        row.addView(av)

        val title = SpannableStringBuilder("VAN")
        val s = title.length
        title.append("TA")
        title.setSpan(ForegroundColorSpan(Theme.AMBER), s, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val names = LinearLayout(this)
        names.orientation = LinearLayout.VERTICAL
        names.addView(tv(title, 26f, Theme.TEXT, true, 0.2f))
        names.addView(tv("AIM  ·  HUD  ·  OVERLAY", 9f, Theme.MUTED, true, 0.3f))
        row.addView(names, lp(0, WRAP, 1f))

        statusChip = tv("", 11f, Theme.MUTED, true, 0.08f)
        statusChip.setPadding(dp(12), dp(6), dp(12), dp(6))
        row.addView(statusChip)
        return row
    }

    private fun buildNav(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.background = rounded(Theme.CARD.withAlpha(0xF2), dp(28).toFloat(), Theme.STROKE, dp(1))
        bar.setPadding(dp(6), dp(4), dp(6), dp(4))
        val names = listOf("หน้าหลัก", "เป้าเล็ง", "HUD")
        for (i in names.indices) {
            val t = NavTab(this, i, names[i])
            t.setOnClickListener { selectTab(i) }
            navTabs.add(t)
            bar.addView(t, lp(0, dp(58), 1f))
        }
        val wrap = FrameLayout(this)
        val params = FrameLayout.LayoutParams(MATCH, WRAP)
        params.setMargins(dp(16), dp(6), dp(16), dp(12))
        wrap.addView(bar, params)
        return wrap
    }

    private fun selectTab(i: Int) {
        for (idx in pages.indices) pages[idx].visibility = if (idx == i) View.VISIBLE else View.GONE
        for (idx in navTabs.indices) navTabs[idx].active = idx == i
    }

    // ================= tab 1: หน้าหลัก =================

    private fun gauge(title: String, a: Int, b: Int): RingGauge {
        val g = RingGauge(this)
        g.title = title
        g.setColors(a, b)
        return g
    }

    private fun tile(title: String): Tile {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.background = rounded(Theme.BG.withAlpha(0xB8), dp(16).toFloat(), Theme.STROKE, dp(1))
        r.setPadding(dp(13), dp(11), dp(13), dp(11))
        r.addView(tv(title, 9f, Theme.MUTED, true, 0.18f))
        val v = tv("—", 17f, Theme.TEXT, true)
        v.setPadding(0, dp(3), 0, 0)
        r.addView(v)
        val s = tv("", 10f, Theme.MUTED)
        s.visibility = View.GONE
        r.addView(s)
        return Tile(r, v, s)
    }

    private fun setTile(t: Tile, value: String, color: Int = Theme.TEXT, sub: String? = null) {
        t.value.text = value
        t.value.setTextColor(color)
        if (sub.isNullOrEmpty()) {
            t.sub.visibility = View.GONE
        } else {
            t.sub.text = sub
            t.sub.visibility = View.VISIBLE
        }
    }

    private fun row2(a: View, b: View, hDp: Int = 0): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        val h = if (hDp > 0) dp(hDp) else WRAP
        r.addView(a, lp(0, h, 1f, 0, 0, dp(5), 0))
        r.addView(b, lp(0, h, 1f, dp(5), 0, 0, 0))
        return r
    }

    private fun chip(text: String, color: Int): TextView {
        val t = tv(text, 11f, color, true, 0.04f)
        t.setPadding(dp(11), dp(6), dp(11), dp(6))
        t.background = rounded(Theme.BG.withAlpha(0xB8), dp(14).toFloat(), Theme.STROKE, dp(1))
        return t
    }

    private fun permRow(title: String, desc: String, onClick: () -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = rounded(Theme.BG.withAlpha(0xB8), dp(16).toFloat(), Theme.AMBER.withAlpha(0x70), dp(1))
        r.setPadding(dp(14), dp(12), dp(14), dp(12))
        r.setOnClickListener { onClick() }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 14f, Theme.TEXT, true))
        col.addView(tv(desc, 11f, Theme.MUTED))
        r.addView(col, lp(0, WRAP, 1f))
        r.addView(tv("อนุญาต ›", 13f, Theme.AMBER, true))
        return r
    }

    private fun kv(parent: LinearLayout, k: String): TextView {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(12), 0, 0)
        r.addView(tv(k, 10f, Theme.MUTED, true, 0.14f), lp(WRAP, WRAP))
        val v = tv("—", 13f, Theme.TEXT, true)
        v.gravity = Gravity.END
        r.addView(v, lp(0, WRAP, 1f, dp(16), 0, 0, 0))
        parent.addView(r)
        return v
    }

    private fun buildHome(): View {
        val col = page()

        // hero
        val hero = card()
        hero.gravity = Gravity.CENTER_HORIZONTAL
        orb = PowerOrb(this)
        orb.setOnClickListener { toggleOverlay() }
        hero.addView(orb, lp(dp(236), dp(236), 0f, 0, dp(2), 0, 0))
        heroTitle = tv("", 22f, Theme.TEXT, true, 0.04f)
        heroTitle.gravity = Gravity.CENTER
        hero.addView(heroTitle, lp(WRAP, WRAP, 0f, 0, dp(2), 0, 0))
        heroSub = tv("", 12f, Theme.MUTED)
        heroSub.gravity = Gravity.CENTER
        hero.addView(heroSub, lp(MATCH, WRAP, 0f, 0, dp(4), 0, 0))

        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.gravity = Gravity.CENTER
        chips.addView(chip(Stats.deviceName().take(22), Theme.TEXT), lp(WRAP, WRAP, 0f, 0, 0, dp(6), 0))
        chips.addView(chip("Android " + Build.VERSION.RELEASE, Theme.ICE))
        hero.addView(chips, lp(MATCH, WRAP, 0f, 0, dp(12), 0, 0))

        startBtn = TextView(this)
        startBtn.textSize = 16f
        startBtn.typeface = Typeface.DEFAULT_BOLD
        startBtn.letterSpacing = 0.1f
        startBtn.gravity = Gravity.CENTER
        startBtn.setPadding(dp(16), dp(17), dp(16), dp(17))
        startBtn.setOnClickListener { toggleOverlay() }
        hero.addView(startBtn, lp(MATCH, WRAP, 0f, 0, dp(16), 0, 0))
        addCard(col, hero)

        // permissions
        permCard = card("การอนุญาตที่ต้องใช้", "แตะเพื่อเปิดหน้าตั้งค่าของระบบ")
        rowOverlay = permRow("แสดงทับแอปอื่น", "จำเป็น — ใช้วางเป้ากับ HUD บนจอเกม") { openOverlaySettings() }
        rowUsage = permRow("เข้าถึงข้อมูลการใช้งาน", "ใช้บอกว่าตอนนี้เปิดแอป/เกมอะไรอยู่") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        rowNotif = permRow("การแจ้งเตือน", "ใช้แสดงปุ่มหยุดบนแถบแจ้งเตือน") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
        }
        for (v in listOf(rowOverlay, rowUsage, rowNotif)) {
            permCard.addView(v, lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        }
        addCard(col, permCard)

        // now playing
        val np = card("NOW PLAYING", "แอป/เกมที่เปิดอยู่ตอนนี้")
        val npRow = LinearLayout(this)
        npRow.orientation = LinearLayout.HORIZONTAL
        npRow.gravity = Gravity.CENTER_VERTICAL
        fgIcon = ImageView(this)
        fgIcon.background = rounded(Theme.BG.withAlpha(0xB8), dp(14).toFloat(), Theme.STROKE, dp(1))
        fgIcon.outlineProvider = ViewOutlineProvider.BACKGROUND
        fgIcon.clipToOutline = true
        fgIcon.scaleType = ImageView.ScaleType.CENTER_CROP
        npRow.addView(fgIcon, lp(dp(48), dp(48), 0f, 0, 0, dp(14), 0))
        val npCol = LinearLayout(this)
        npCol.orientation = LinearLayout.VERTICAL
        fgName = tv("—", 17f, Theme.TEXT, true)
        fgName.maxLines = 1
        fgName.ellipsize = android.text.TextUtils.TruncateAt.END
        fgPkg = tv("", 11f, Theme.MUTED)
        fgPkg.maxLines = 1
        fgPkg.ellipsize = android.text.TextUtils.TruncateAt.END
        npCol.addView(fgName)
        npCol.addView(fgPkg)
        npRow.addView(npCol, lp(0, WRAP, 1f))
        np.addView(npRow, lp(MATCH, WRAP, 0f, 0, dp(14), 0, 0))
        addCard(col, np)

        // gauges
        gCpu = gauge("CPU", Theme.AMBER, Theme.EMBER)
        gGpu = gauge("GPU", Theme.VIOLET, Theme.ICE)
        gBatt = gauge("BATT", Theme.GREEN, Theme.ICE)
        gRam = gauge("RAM", Theme.ICE, Theme.VIOLET)
        val g = card("LIVE", "ข้อมูลเครื่องแบบสด อัปเดตทุกวินาที")
        g.addView(row2(gCpu, gGpu, 132), lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        g.addView(row2(gBatt, gRam, 132), lp(MATCH, WRAP, 0f, 0, dp(4), 0, 0))
        hint = tv("", 11f, Theme.MUTED)
        hint.setPadding(0, dp(10), 0, 0)
        hint.visibility = View.GONE
        g.addView(hint)
        addCard(col, g)

        // system tiles
        tTemp = tile("BATT TEMP")
        tPower = tile("POWER")
        tPing = tile("PING")
        tNet = tile("NETWORK")
        tDisplay = tile("DISPLAY")
        tDisk = tile("STORAGE")
        tThermal = tile("THERMAL")
        tEta = tile("TIME LEFT")
        val t = card("SYSTEM")
        t.addView(row2(tTemp.root, tPower.root), lp(MATCH, WRAP, 0f, 0, dp(12), 0, 0))
        t.addView(row2(tPing.root, tNet.root), lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        t.addView(row2(tDisplay.root, tDisk.root), lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        t.addView(row2(tThermal.root, tEta.root), lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
        addCard(col, t)

        // cpu cores
        val cc = card("CPU CORES", "ความเร็วคล็อกแต่ละคอร์ (GHz)")
        coreBars = CoreBars(this)
        cc.addView(coreBars, lp(MATCH, dp(130), 0f, 0, dp(12), 0, 0))
        coreInfo = tv("", 11f, Theme.MUTED)
        coreInfo.setPadding(0, dp(8), 0, 0)
        cc.addView(coreInfo)
        addCard(col, cc)

        // history
        spCpu = Sparkline(this)
        spCpu.color = Theme.AMBER
        spGpu = Sparkline(this)
        spGpu.color = Theme.VIOLET
        val h = card("HISTORY", "ย้อนหลัง 60 วินาที")
        h.addView(tv("CPU", 10f, Theme.AMBER, true, 0.16f), lp(WRAP, WRAP, 0f, 0, dp(12), 0, 0))
        h.addView(spCpu, lp(MATCH, dp(80), 0f, 0, dp(4), 0, 0))
        h.addView(tv("GPU", 10f, Theme.VIOLET, true, 0.16f), lp(WRAP, WRAP, 0f, 0, dp(12), 0, 0))
        h.addView(spGpu, lp(MATCH, dp(80), 0f, 0, dp(4), 0, 0))
        addCard(col, h)

        // device
        val dv = card("DEVICE")
        dDevice = kv(dv, "รุ่น")
        dSoc = kv(dv, "ชิป")
        dGpu = kv(dv, "GPU")
        dAndroid = kv(dv, "ระบบ")
        dRam = kv(dv, "แรม")
        dScreen = kv(dv, "หน้าจอ")
        addCard(col, dv)

        return col
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
        } else if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "ต้องอนุญาตแสดงทับแอปอื่นก่อน", Toast.LENGTH_LONG).show()
            openOverlaySettings()
        } else {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        handler.postDelayed({ refreshHero() }, 400)
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        refreshPerms()
    }

    private fun refreshPerms() {
        val overlayOk = Settings.canDrawOverlays(this)
        val usageOk = Stats.hasUsageAccess(this)
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        rowOverlay.visibility = if (overlayOk) View.GONE else View.VISIBLE
        rowUsage.visibility = if (usageOk) View.GONE else View.VISIBLE
        rowNotif.visibility = if (notifOk) View.GONE else View.VISIBLE
        permCard.visibility = if (overlayOk && usageOk && notifOk) View.GONE else View.VISIBLE
    }

    private fun refreshHero() {
        val on = OverlayService.running
        orb.on = on
        if (on) {
            heroTitle.text = "กำลังทำงาน"
            heroTitle.setTextColor(Theme.GREEN)
            heroSub.text = "เป้ากับ HUD ลอยทับหน้าจออยู่ สลับไปเปิดเกมได้เลย"
            startBtn.text = "■   หยุด"
            startBtn.setTextColor(Color.WHITE)
            startBtn.background = gradient(Theme.DANGER, 0xFFD62F8A.toInt(), dp(20).toFloat())
        } else {
            heroTitle.text = "พร้อมใช้งาน"
            heroTitle.setTextColor(Theme.TEXT)
            heroSub.text = "แตะรูปหรือกดปุ่มด้านล่าง แล้วเปิดเกม ใช้ปุ่มลอยขยับเป้าให้ตรงจุด"
            startBtn.text = "▶   เริ่มเป้าเล็ง"
            startBtn.setTextColor(Color.BLACK)
            startBtn.background = gradient(Theme.AMBER, Theme.EMBER, dp(20).toFloat())
        }
        statusChip.text = if (on) "● ON" else "● OFF"
        val cc = if (on) Theme.GREEN else Theme.MUTED
        statusChip.setTextColor(cc)
        statusChip.background = rounded(Theme.CARD, dp(14).toFloat(), cc, dp(1))
    }

    private fun fmtHours(h: Float): String {
        val mins = (h * 60f).toInt()
        return if (mins >= 60) "${mins / 60} ชม. ${mins % 60} น." else "$mins น."
    }

    private fun loadIcon(pkg: String?) {
        if (pkg == iconPkg) return
        iconPkg = pkg
        if (pkg == null) {
            fgIcon.setImageDrawable(null)
            return
        }
        try {
            fgIcon.setImageDrawable(packageManager.getApplicationIcon(pkg))
        } catch (e: Exception) {
            fgIcon.setImageDrawable(null)
        }
    }

    private fun refreshDash() {
        val b = Stats.battery(this)
        gBatt.set(
            if (b.percent >= 0) b.percent else null,
            if (b.percent >= 0) "${b.percent}%" + (if (b.charging) "⚡" else "") else "—",
            b.percent in 0..15
        )
        val cpu = Stats.cpuPercent()
        gCpu.set(cpu, cpu?.let { "$it%" } ?: "N/A", (cpu ?: 0) >= 85)
        spCpu.push(cpu)
        val gpu = Stats.gpuPercent()
        gGpu.set(gpu, gpu?.let { (if (Stats.gpuEstimated) "~" else "") + "$it%" } ?: "N/A", (gpu ?: 0) >= 85)
        spGpu.push(gpu)
        val m = Stats.memory(this)
        gRam.set(m.pct, "${m.pct}%", m.pct >= 90)

        // now playing
        if (Stats.hasUsageAccess(this)) {
            val fg = Stats.foreground(this)
            fgName.text = fg?.label ?: "—"
            fgName.setTextColor(Theme.TEXT)
            fgPkg.text = fg?.pkg ?: ""
            loadIcon(fg?.pkg)
        } else {
            fgName.text = "ยังไม่ได้อนุญาต"
            fgName.setTextColor(Theme.AMBER)
            fgPkg.text = "เปิดสิทธิ์ \"เข้าถึงข้อมูลการใช้งาน\" เพื่อดูชื่อเกม"
            loadIcon(null)
        }

        // tiles
        setTile(tTemp, String.format(Locale.US, "%.1f°C", b.tempC), tempColor(b.tempC))
        val w = b.powerW
        val ma = b.currentMa
        setTile(
            tPower,
            if (w != null) String.format(Locale.US, "%.1f W", w) else "—",
            Theme.TEXT,
            if (ma != null) "$ma mA " + (if (b.charging) "(ชาร์จ)" else "(ใช้)") else null
        )
        val ping = Stats.pingMs
        setTile(tPing, if (ping >= 0) "$ping ms" else "—", pingColor(ping))
        val net = Stats.network(this)
        setTile(tNet, net.label, if (net.online) Theme.TEXT else Theme.MUTED, net.detail)
        val hz = Stats.refreshHz(this)
        val dm = resources.displayMetrics
        setTile(tDisplay, if (hz > 0) "$hz Hz" else "—", Theme.TEXT, "${dm.widthPixels}×${dm.heightPixels}")
        val dsk = Stats.diskPercent()
        setTile(
            tDisk, "$dsk%", if (dsk >= 92) Theme.DANGER else Theme.TEXT,
            String.format(Locale.US, "ว่าง %.1f GB", Stats.diskFreeGb())
        )
        setTile(tThermal, Stats.thermalLabel(this) ?: "—")
        val eta = b.etaHours
        if (eta != null && eta > 0f && eta < 48f) {
            setTile(tEta, fmtHours(eta), Theme.TEXT, if (b.charging) "จนชาร์จเต็ม" else "ที่ใช้งานแบบนี้")
        } else {
            setTile(tEta, "—", Theme.MUTED, "ประเมินไม่ได้ในเครื่องนี้")
        }

        // cores
        val cores = Stats.cores()
        coreBars.set(cores)
        var online = 0
        var top = 0L
        for (c in cores) {
            if (c.online) {
                online++
                if (c.curKhz > top) top = c.curKhz
            }
        }
        coreInfo.text = if (online == 0) {
            "เครื่องนี้ไม่เปิดให้แอปอ่านคล็อกรายคอร์"
        } else {
            String.format(Locale.US, "%d คอร์  ·  เร็วสุดตอนนี้ %.2f GHz", cores.size, top / 1_000_000f)
        }

        // device
        dDevice.text = Stats.deviceName()
        dSoc.text = Stats.socName()
        dGpu.text = Stats.gpuName ?: "กำลังอ่าน…"
        dAndroid.text = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        dRam.text = String.format(Locale.US, "%.1f GB", m.totalMb / 1024f)
        dScreen.text = if (hz > 0) "${dm.widthPixels}×${dm.heightPixels} · $hz Hz" else "${dm.widthPixels}×${dm.heightPixels}"

        val notes = ArrayList<String>()
        if (gpu == null) notes.add("GPU: เครื่องนี้ไม่เปิดให้แอปอ่านค่า (Android จำกัดสิทธิ์)")
        else if (Stats.gpuEstimated) notes.add("GPU: ค่า ~ คือประเมินจากคล็อก ไม่ใช่โหลดจริง")
        if (cpu == null) notes.add("CPU: เครื่องนี้ไม่เปิดให้แอปอ่านค่า")
        hint.text = notes.joinToString("\n")
        hint.visibility = if (notes.isEmpty()) View.GONE else View.VISIBLE
    }

    // ================= tab 2: เป้าเล็ง =================

    private val presets = listOf(
        Triple("ขาว", 0, 0), Triple("แดง", 0, 100), Triple("ส้ม", 28, 100), Triple("เหลือง", 50, 100),
        Triple("เขียว", 140, 100), Triple("ฟ้า", 187, 100), Triple("ม่วง", 265, 70), Triple("ชมพู", 325, 80)
    )

    private fun buildStyleStrip(): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val boxes = ArrayList<FrameLayout>()
        val restyle = {
            val sel = prefs.getInt("style", 0)
            for (i in boxes.indices) {
                val on = i == sel
                boxes[i].background = rounded(
                    if (on) Theme.AMBER.withAlpha(0x26) else Theme.BG.withAlpha(0xB8),
                    dp(18).toFloat(), if (on) Theme.AMBER else Theme.STROKE, dp(if (on) 2 else 1)
                )
            }
        }
        val names = CrosshairView.NAMES
        for (i in names.indices) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            val box = FrameLayout(this)
            box.addView(CrosshairView(this, i, true), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
            box.setOnClickListener {
                prefs.edit().putInt("style", i).apply()
                restyle()
            }
            boxes.add(box)
            cell.addView(box, lp(dp(66), dp(66)))
            cell.addView(tv(names[i], 9f, Theme.MUTED, true, 0.1f), lp(WRAP, WRAP, 0f, 0, dp(6), 0, 0))
            row.addView(cell, lp(WRAP, WRAP, 0f, 0, 0, dp(10), 0))
        }
        syncers.add(restyle)
        restyle()
        hs.addView(row)
        return hs
    }

    private fun buildSwatches(): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val dots = ArrayList<View>()
        val restyle = {
            val h = prefs.getInt("hue", 0)
            val s = prefs.getInt("sat", 100)
            for (i in presets.indices) {
                val p = presets[i]
                val on = p.second == h && p.third == s
                val col = Color.HSVToColor(floatArrayOf(p.second.toFloat(), p.third / 100f, 1f))
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(col)
                g.setStroke(dp(if (on) 3 else 1), if (on) Color.WHITE else Theme.STROKE)
                dots[i].background = g
            }
        }
        for (p in presets) {
            val v = View(this)
            v.setOnClickListener {
                prefs.edit().putInt("hue", p.second).putInt("sat", p.third).apply()
                for (s in syncers) s()
            }
            dots.add(v)
            row.addView(v, lp(dp(36), dp(36), 0f, 0, 0, dp(10), 0))
        }
        syncers.add(restyle)
        restyle()
        hs.addView(row)
        return hs
    }

    private fun buildAim(): View {
        val col = page()

        val pv = card("PREVIEW", "ตัวอย่างเป้าตามที่ตั้งค่า")
        val box = FrameLayout(this)
        box.addView(GridBackdrop(this), FrameLayout.LayoutParams(MATCH, MATCH))
        preview = CrosshairView(this)
        box.addView(preview, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        pv.addView(box, lp(MATCH, dp(180), 0f, 0, dp(12), 0, 0))
        addCard(col, pv)

        val st = card("STYLE", "เลือกรูปแบบเป้า 12 แบบ")
        st.addView(buildStyleStrip(), lp(MATCH, WRAP, 0f, 0, dp(14), 0, 0))
        addCard(col, st)

        val cl = card("COLOR")
        cl.addView(buildSwatches(), lp(MATCH, WRAP, 0f, 0, dp(12), 0, 0))
        slider(cl, "เฉดสี", "hue", 0, 360, 0)
        slider(cl, "ความเข้มสี (0 = ขาว)", "sat", 0, 100, 100)
        slider(cl, "ความโปร่งใส", "alpha", 10, 100, 100, "%")
        addCard(col, cl)

        val sh = card("SHAPE")
        slider(sh, "ขนาด", "size", 20, 160, 48, "dp")
        slider(sh, "ความหนา", "thick", 1, 8, 2, "dp")
        slider(sh, "ช่องว่างกลางเป้า", "gap", 0, 30, 6, "dp")
        sh.addView(switchRow("ขอบดำ (อ่านง่ายบนพื้นสว่าง)", "outline", true, true))
        sh.addView(switchRow("จุดกลางเป้า", "dot", true, true))
        addCard(col, sh)

        val ps = card("POSITION", "ปรับตำแหน่งเป้า หรือใช้ปุ่มลอยตอนเล่น")
        slider(ps, "เลื่อนซ้าย (-) / ขวา (+)", "offx", -300, 300, 0)
        slider(ps, "เลื่อนขึ้น (-) / ลง (+)", "offy", -300, 300, 0)
        slider(ps, "ระยะต่อการแตะปุ่มลอย", "step", 1, 5, 1, "dp")
        ps.addView(switchRow("แสดงปุ่มลอย (รูปปุ่ม + ลูกศร)", "move_on", true))
        val reset = tv("รีเซ็ตเป้าทั้งหมด", 14f, Theme.TEXT, true)
        reset.gravity = Gravity.CENTER
        reset.background = rounded(Theme.CARD_HI, dp(16).toFloat(), Theme.STROKE, dp(1))
        reset.setPadding(dp(16), dp(14), dp(16), dp(14))
        reset.setOnClickListener {
            prefs.edit().putInt("style", 0).apply()
            for (r in resetters) r()
            for (s in syncers) s()
        }
        ps.addView(reset, lp(MATCH, WRAP, 0f, 0, dp(18), 0, 0))
        addCard(col, ps)
        return col
    }

    // ================= tab 3: HUD =================

    private fun refreshHudPreview() {
        if (!::hudPreview.isInitialized) return
        hudPreview.textSize = Hud.textSizeSp(prefs)
        val a = prefs.getInt("hud_alpha", 75).coerceIn(20, 100) * 255 / 100
        hudPreview.background = rounded(Theme.BG.withAlpha(a), dp(12).toFloat(), Theme.STROKE, dp(1))
        hudPreview.text = Hud.build(this, prefs, startedAt)
    }

    private fun buildHudTab(): View {
        val col = page()

        val pv = card("PREVIEW", "หน้าตา HUD ที่จะลอยบนจอเกม")
        hudPreview = TextView(this)
        hudPreview.typeface = Typeface.MONOSPACE
        hudPreview.setTextColor(Theme.TEXT)
        hudPreview.setPadding(dp(12), dp(9), dp(14), dp(9))
        hudPreview.setLineSpacing(0f, 1.1f)
        val holder = FrameLayout(this)
        holder.background = rounded(Theme.BG2, dp(18).toFloat(), Theme.STROKE, dp(1))
        holder.setPadding(dp(14), dp(14), dp(14), dp(14))
        holder.addView(hudPreview, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.TOP))
        pv.addView(holder, lp(MATCH, WRAP, 0f, 0, dp(12), 0, 0))
        addCard(col, pv)

        val sw = card("METRICS", "เลือกว่าจะโชว์อะไรบ้าง")
        sw.addView(switchRow("แสดง HUD", "hud_on", true))
        sw.addView(switchRow("แอปที่ใช้อยู่", "hud_app", true))
        sw.addView(switchRow("แบตเตอรี่ + อุณหภูมิ + วัตต์", "hud_bat", true))
        sw.addView(switchRow("CPU", "hud_cpu", true))
        sw.addView(switchRow("GPU", "hud_gpu", true))
        sw.addView(switchRow("RAM", "hud_ram", true))
        sw.addView(switchRow("Ping", "hud_ping", true))
        sw.addView(switchRow("เครือข่าย + อัตรารีเฟรชจอ", "hud_net", true))
        sw.addView(switchRow("นาฬิกา + เวลาที่เปิดเป้า", "hud_time", true))
        addCard(col, sw)

        val ly = card("LAYOUT")
        val l1 = tv("รูปแบบ", 13f)
        l1.setPadding(0, dp(12), 0, 0)
        ly.addView(l1)
        ly.addView(segmented(listOf("เต็ม (หลายบรรทัด)", "กะทัดรัด (บรรทัดเดียว)"), "hud_mode", 0))
        val l2 = tv("ตำแหน่ง", 13f)
        l2.setPadding(0, dp(14), 0, 0)
        ly.addView(l2)
        ly.addView(segmented(listOf("ซ้ายบน", "ขวาบน", "ซ้ายล่าง", "ขวาล่าง"), "hud_pos", 0))
        val l3 = tv("ขนาดตัวอักษร", 13f)
        l3.setPadding(0, dp(14), 0, 0)
        ly.addView(l3)
        ly.addView(segmented(listOf("เล็ก", "กลาง", "ใหญ่"), "hud_size", 1))
        slider(ly, "ความโปร่งใสพื้นหลัง", "hud_alpha", 20, 100, 75, "%", false)
        addCard(col, ly)

        val ov = card("OVERLAY", "ตัวช่วยตอนเล่นเกม")
        ov.addView(switchRow("กันจอดับระหว่างเปิดเป้า", "keep_on", false))
        addCard(col, ov)

        return col
    }
}
