package com.vanta.aim

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.View

const val PREFS = "vanta"

/** โทนสีจากรูปปก: ดำม่วงลึก + ไฟอำพัน + ตาฟ้าน้ำแข็ง */
object Theme {
    val BG = 0xFF07060D.toInt()
    val BG2 = 0xFF0D0B17.toInt()
    val CARD = 0xFF14111F.toInt()
    val CARD_HI = 0xFF1F1A33.toInt()
    val STROKE = 0xFF2A2342.toInt()
    val AMBER = 0xFFFFB02E.toInt()
    val EMBER = 0xFFFF6A1F.toInt()
    val VIOLET = 0xFF8E63FF.toInt()
    val ICE = 0xFF56E1FF.toInt()
    val GREEN = 0xFF3DF2A5.toInt()
    val DANGER = 0xFFFF4D6D.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFF8C86A8.toInt()
    val LABEL = 0xFF9A94B8.toInt()
}

fun Int.withAlpha(a: Int): Int = (this and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun View.dp(v: Int): Int = context.dp(v)

fun rounded(fill: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.RECTANGLE
    g.cornerRadius = radius
    g.setColor(fill)
    if (strokeW > 0) g.setStroke(strokeW, stroke)
    return g
}

fun gradient(
    c1: Int,
    c2: Int,
    radius: Float,
    o: GradientDrawable.Orientation = GradientDrawable.Orientation.LEFT_RIGHT
): GradientDrawable {
    val g = GradientDrawable(o, intArrayOf(c1, c2))
    g.cornerRadius = radius
    return g
}

/** พื้นการ์ดแบบกระจกเข้ม ไล่สีเฉียง ๆ มีขอบบาง */
fun glass(radius: Float, strokePx: Int): GradientDrawable {
    val g = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Theme.CARD_HI.withAlpha(0xEE), Theme.CARD.withAlpha(0xEE))
    )
    g.cornerRadius = radius
    g.setStroke(strokePx, Theme.STROKE)
    return g
}

/** เขียว = สบาย, เหลือง = เริ่มหนัก, แดง = หนักมาก */
fun levelColor(p: Int): Int = if (p < 60) Theme.GREEN else if (p < 85) Theme.AMBER else Theme.DANGER

fun batteryColor(p: Int): Int = if (p <= 15) Theme.DANGER else if (p <= 30) Theme.AMBER else Theme.GREEN

fun tempColor(c: Float): Int = if (c >= 43f) Theme.DANGER else if (c >= 39f) Theme.AMBER else Theme.TEXT

fun pingColor(ms: Int): Int =
    if (ms < 0) Theme.MUTED else if (ms < 60) Theme.GREEN else if (ms < 120) Theme.AMBER else Theme.DANGER
