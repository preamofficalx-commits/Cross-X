package com.vanta.aim

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** วงแหวนวัดค่า 270° ไล่สี มีแสงเรือง และเลื่อนค่าแบบนุ่ม ๆ */
class RingGauge(ctx: Context) : View(ctx) {
    var title = ""
    private var valueText = "—"
    private var shown = 0f
    private var warn = false
    private var cA = Theme.AMBER
    private var cB = Theme.EMBER
    private val rect = RectF()
    private var anim: ValueAnimator? = null

    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val vp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        track.style = Paint.Style.STROKE
        track.strokeCap = Paint.Cap.ROUND
        track.color = Theme.STROKE
        glow.style = Paint.Style.STROKE
        glow.strokeCap = Paint.Cap.ROUND
        arc.style = Paint.Style.STROKE
        arc.strokeCap = Paint.Cap.ROUND
        vp.color = Theme.TEXT
        vp.textAlign = Paint.Align.CENTER
        vp.typeface = Typeface.DEFAULT_BOLD
        tp.color = Theme.MUTED
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.letterSpacing = 0.15f
    }

    fun setColors(a: Int, b: Int) {
        cA = a
        cB = b
        rebuild()
        invalidate()
    }

    fun set(pct: Int?, text: String, warn: Boolean = false) {
        valueText = text
        if (this.warn != warn) {
            this.warn = warn
            rebuild()
        }
        val target = (pct ?: 0).coerceIn(0, 100).toFloat()
        anim?.cancel()
        val a = ValueAnimator.ofFloat(shown, target)
        a.duration = 450
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener {
            shown = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun rebuild() {
        if (width == 0) return
        val a = if (warn) Theme.DANGER else cA
        val b = if (warn) 0xFFFF8FA3.toInt() else cB
        arc.shader = SweepGradient(width / 2f, height / 2f, intArrayOf(a, b), floatArrayOf(0f, 0.75f))
        glow.shader = SweepGradient(
            width / 2f, height / 2f,
            intArrayOf(a.withAlpha(0x50), b.withAlpha(0x50)), floatArrayOf(0f, 0.75f)
        )
    }

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        val sw = s * 0.085f
        track.strokeWidth = sw
        arc.strokeWidth = sw
        glow.strokeWidth = sw * 1.9f
        val cx = width / 2f
        val cy = height / 2f
        val r = s / 2f - sw * 1.2f
        rect.set(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rect, 135f, 270f, false, track)
        if (shown > 0.5f) {
            c.save()
            c.rotate(135f, cx, cy)
            c.drawArc(rect, 0f, 270f * shown / 100f, false, glow)
            c.drawArc(rect, 0f, 270f * shown / 100f, false, arc)
            c.restore()
        }
        vp.textSize = s * (if (valueText.length > 4) 0.19f else 0.25f)
        val vy = cy - (vp.ascent() + vp.descent()) / 2f - s * 0.03f
        c.drawText(valueText, cx, vy, vp)
        tp.textSize = s * 0.085f
        c.drawText(title, cx, cy + r * 0.80f + tp.textSize * 0.35f, tp)
    }
}

/** กราฟเส้นย้อนหลัง 60 วินาที */
class Sparkline(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val data = ArrayList<Int>()
    private val maxPts = 60
    var color = Theme.AMBER
        set(v) {
            field = v
            line.color = v
            rebuild()
        }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint()
    private val path = Path()
    private val area = Path()

    init {
        line.style = Paint.Style.STROKE
        line.strokeWidth = 2f * d
        line.strokeJoin = Paint.Join.ROUND
        line.strokeCap = Paint.Cap.ROUND
        line.color = Theme.AMBER
        fill.style = Paint.Style.FILL
        grid.color = 0x14FFFFFF
        grid.strokeWidth = 1f * d
    }

    fun push(v: Int?) {
        data.add((v ?: 0).coerceIn(0, 100))
        if (data.size > maxPts) data.removeAt(0)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    private fun rebuild() {
        if (height == 0) return
        fill.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(), color.withAlpha(110), color.withAlpha(0), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..3) c.drawLine(0f, h * i / 4f, w, h * i / 4f, grid)
        if (data.size < 2) return
        val step = w / (maxPts - 1)
        val x0 = w - (data.size - 1) * step
        path.reset()
        area.reset()
        data.forEachIndexed { i, v ->
            val x = x0 + i * step
            val y = h - (h - 4f * d) * v / 100f - 2f * d
            if (i == 0) {
                path.moveTo(x, y)
                area.moveTo(x, h)
                area.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                area.lineTo(x, y)
            }
        }
        area.lineTo(w, h)
        area.close()
        c.drawPath(area, fill)
        c.drawPath(path, line)
    }
}

/** แถบความเร็วคล็อกของแต่ละคอร์ CPU */
class CoreBars(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private var cores: List<CoreInfo> = emptyList()
    private val rect = RectF()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val idx = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        track.color = Theme.BG.withAlpha(0xCC)
        txt.color = Theme.TEXT
        txt.textAlign = Paint.Align.CENTER
        txt.typeface = Typeface.DEFAULT_BOLD
        txt.textSize = 10f * d
        idx.color = Theme.MUTED
        idx.textAlign = Paint.Align.CENTER
        idx.typeface = Typeface.DEFAULT_BOLD
        idx.textSize = 9f * d
    }

    fun set(list: List<CoreInfo>) {
        cores = list
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fill.shader = LinearGradient(
            0f, 16f * d, 0f, h - 16f * d, Theme.EMBER, Theme.VIOLET, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val n = cores.size
        if (n == 0) return
        val gap = 6f * d
        val bw = (width - gap * (n - 1)) / n
        val top = 16f * d
        val bottom = height - 16f * d
        val bh = bottom - top
        val rad = min(bw / 2f, 6f * d)
        for (i in 0 until n) {
            val core = cores[i]
            val x = i * (bw + gap)
            rect.set(x, top, x + bw, bottom)
            c.drawRoundRect(rect, rad, rad, track)
            if (core.online && core.maxKhz > 0L) {
                val fh = (bh * core.ratio).coerceAtLeast(rad * 1.2f)
                rect.set(x, bottom - fh, x + bw, bottom)
                c.drawRoundRect(rect, rad, rad, fill)
            }
            val label = if (core.online) String.format(Locale.US, "%.1f", core.curKhz / 1_000_000f) else "–"
            c.drawText(label, x + bw / 2f, top - 4f * d, txt)
            c.drawText(i.toString(), x + bw / 2f, height - 3f * d, idx)
        }
    }
}

/** ปุ่มเปิด/ปิดตรงกลางหน้าหลัก: ใช้รูปปกเดิม มีวงแหวน เข็มเรือง และคลื่นกระจาย */
class PowerOrb(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    var on: Boolean = false
        set(v) {
            if (field != v) {
                field = v
                syncAnim()
                invalidate()
            }
        }

    private var pulse = 0f
    private var anim: ValueAnimator? = null
    private val avatarMatrix = Matrix()
    private var avatarShader: BitmapShader? = null
    private var glowOn: RadialGradient? = null
    private var glowOff: RadialGradient? = null
    private var ringOn: SweepGradient? = null

    private var cx = 0f
    private var cy = 0f
    private var outerR = 0f
    private var ringR = 0f
    private var imgR = 0f

    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tickP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val waveP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val imgP = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dimP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val baseP = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        ringP.style = Paint.Style.STROKE
        ringP.strokeCap = Paint.Cap.ROUND
        tickP.style = Paint.Style.STROKE
        tickP.strokeCap = Paint.Cap.ROUND
        waveP.style = Paint.Style.STROKE
        dimP.color = 0xB3000000.toInt()
        baseP.color = Theme.BG
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val s = min(w, h).toFloat()
        cx = w / 2f
        cy = h / 2f
        outerR = s / 2f - 2f * d
        ringR = outerR * 0.74f
        imgR = ringR - 9f * d
        ringP.strokeWidth = 4f * d
        tickP.strokeWidth = 2f * d
        waveP.strokeWidth = 2f * d

        glowOn = RadialGradient(
            cx, cy, outerR, intArrayOf(Theme.AMBER.withAlpha(0x70), Theme.VIOLET.withAlpha(0x28), Color.TRANSPARENT),
            floatArrayOf(0.45f, 0.75f, 1f), Shader.TileMode.CLAMP
        )
        glowOff = RadialGradient(
            cx, cy, outerR, intArrayOf(Theme.VIOLET.withAlpha(0x34), Color.TRANSPARENT),
            floatArrayOf(0.5f, 1f), Shader.TileMode.CLAMP
        )
        ringOn = SweepGradient(
            cx, cy, intArrayOf(Theme.AMBER, Theme.EMBER, Theme.VIOLET, Theme.AMBER), null
        )

        val dia = (imgR * 2f).toInt().coerceAtLeast(2)
        try {
            val src = BitmapFactory.decodeResource(resources, R.drawable.floating_avatar)
            val bmp = Bitmap.createScaledBitmap(src, dia, dia, true)
            val sh = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            avatarMatrix.reset()
            avatarMatrix.postTranslate(cx - imgR, cy - imgR)
            sh.setLocalMatrix(avatarMatrix)
            avatarShader = sh
            imgP.shader = sh
        } catch (e: Throwable) {
            avatarShader = null
            imgP.shader = null
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        syncAnim()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    private fun syncAnim() {
        anim?.cancel()
        anim = null
        if (on && isAttachedToWindow) {
            val a = ValueAnimator.ofFloat(0f, 1f)
            a.duration = 2400
            a.repeatCount = ValueAnimator.INFINITE
            a.interpolator = LinearInterpolator()
            a.addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            a.start()
            anim = a
        }
    }

    override fun onDraw(c: Canvas) {
        if (outerR <= 0f) return
        // แสงเรือง
        glowP.shader = if (on) glowOn else glowOff
        glowP.alpha = if (on) (190 + 65 * sin(pulse * 6.2831853f)).toInt().coerceIn(0, 255) else 255
        c.drawCircle(cx, cy, outerR, glowP)

        // ขีดรอบวง
        val spin = if (on) (System.currentTimeMillis() % 24000L) / 24000f * 360f else 0f
        c.save()
        c.rotate(spin, cx, cy)
        val ticks = 60
        val t0 = ringR + 10f * d
        val t1 = ringR + 17f * d
        for (i in 0 until ticks) {
            val ang = i * 6.2831853f / ticks
            val lit = on && (i % 5 == 0)
            tickP.color = if (on) Theme.AMBER.withAlpha(if (lit) 0xFF else 0x66) else Theme.STROKE
            val l = if (i % 5 == 0) t1 + 3f * d else t1
            c.drawLine(
                cx + cos(ang) * t0, cy + sin(ang) * t0,
                cx + cos(ang) * l, cy + sin(ang) * l, tickP
            )
        }
        c.restore()

        // วงแหวนหลัก
        c.drawCircle(cx, cy, ringR + 2f * d, baseP)
        if (on) {
            c.save()
            c.rotate(-spin * 2f, cx, cy)
            ringP.shader = ringOn
            c.drawCircle(cx, cy, ringR, ringP)
            c.restore()
            ringP.shader = null
        } else {
            ringP.shader = null
            ringP.color = Theme.STROKE
            c.drawCircle(cx, cy, ringR, ringP)
        }

        // รูปปก
        if (avatarShader != null) {
            c.drawCircle(cx, cy, imgR, imgP)
        } else {
            c.drawCircle(cx, cy, imgR, baseP)
        }
        if (!on) c.drawCircle(cx, cy, imgR, dimP)

        // คลื่นกระจาย
        if (on) {
            val r = ringR + pulse * (outerR - ringR)
            waveP.color = Theme.AMBER.withAlpha(((1f - pulse) * 150).toInt())
            c.drawCircle(cx, cy, r, waveP)
        }
    }
}

/** ปุ่มแท็บล่าง วาดไอคอนเอง */
class NavTab(ctx: Context, private val kind: Int, private val label: String) : View(ctx) {
    private val d = resources.displayMetrics.density
    var active: Boolean = false
        set(v) {
            field = v
            invalidate()
        }

    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ifill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pillLine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        ip.style = Paint.Style.STROKE
        ip.strokeCap = Paint.Cap.ROUND
        ip.strokeWidth = 2f * d
        ifill.style = Paint.Style.FILL
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.textSize = 11f * d
        pill.style = Paint.Style.FILL
        pillLine.style = Paint.Style.STROKE
        pillLine.strokeWidth = 1f * d
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val col = if (active) Theme.AMBER else Theme.MUTED
        if (active) {
            rect.set(4f * d, 3f * d, w - 4f * d, h - 3f * d)
            pill.color = Theme.AMBER.withAlpha(0x22)
            pillLine.color = Theme.AMBER.withAlpha(0x66)
            c.drawRoundRect(rect, 18f * d, 18f * d, pill)
            c.drawRoundRect(rect, 18f * d, 18f * d, pillLine)
        }
        ip.color = col
        ifill.color = col
        tp.color = if (active) Theme.TEXT else Theme.MUTED
        val cx = w / 2f
        val cy = h * 0.40f
        val r = 8.5f * d
        when (kind) {
            0 -> {
                rect.set(cx - r, cy - r, cx + r, cy + r)
                c.drawArc(rect, 305f, 290f, false, ip)
                c.drawLine(cx, cy - r * 1.15f, cx, cy - r * 0.1f, ip)
            }
            1 -> {
                c.drawCircle(cx, cy, r * 0.62f, ip)
                c.drawLine(cx - r, cy, cx - r * 0.3f, cy, ip)
                c.drawLine(cx + r * 0.3f, cy, cx + r, cy, ip)
                c.drawLine(cx, cy - r, cx, cy - r * 0.3f, ip)
                c.drawLine(cx, cy + r * 0.3f, cx, cy + r, ip)
                c.drawCircle(cx, cy, 1.4f * d, ifill)
            }
            else -> {
                c.drawLine(cx - r, cy - r * 0.7f, cx + r, cy - r * 0.7f, ip)
                c.drawLine(cx - r, cy, cx + r * 0.3f, cy, ip)
                c.drawLine(cx - r, cy + r * 0.7f, cx + r * 0.65f, cy + r * 0.7f, ip)
            }
        }
        c.drawText(label, cx, h * 0.84f, tp)
    }
}

/** พื้นหลังแอป: ดำม่วง + แสงม่วงมุมขวาบน + แสงอำพันมุมซ้ายล่าง + ฝุ่นดาว */
class AuroraBackground(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private val stars = FloatArray(90)

    init {
        var seed = 7L
        for (i in stars.indices) {
            seed = (seed * 1103515245L + 12345L) and 0x7fffffffL
            stars[i] = (seed % 1000L) / 1000f
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Theme.BG)
        p.shader = RadialGradient(
            w * 0.95f, h * 0.04f, w * 0.95f,
            Theme.VIOLET.withAlpha(0x4A), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = RadialGradient(
            w * 0.04f, h * 0.98f, w * 0.9f,
            Theme.EMBER.withAlpha(0x2E), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        var i = 0
        while (i + 2 < stars.size) {
            p.color = Color.WHITE.withAlpha(8 + (stars[i + 2] * 40).toInt())
            c.drawCircle(stars[i] * w, stars[i + 1] * h, (0.6f + stars[i + 2]) * d, p)
            i += 3
        }
    }
}

/** ฉากจำลองสำหรับดูตัวอย่างเป้า: กริดจาง ๆ + เส้นกลางจอ */
class GridBackdrop(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val gridP = Paint()
    private val guideP = Paint()

    init {
        gridP.color = 0x12FFFFFF
        gridP.strokeWidth = 1f * d
        guideP.color = Theme.AMBER.withAlpha(0x30)
        guideP.strokeWidth = 1f * d
        background = rounded(Theme.BG2, 16f * d, Theme.STROKE, (1 * d).toInt())
        clipToOutline = true
        outlineProvider = ViewOutlineProvider.BACKGROUND
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val step = 24f * d
        var x = 0f
        while (x < w) {
            c.drawLine(x, 0f, x, h, gridP)
            x += step
        }
        var y = 0f
        while (y < h) {
            c.drawLine(0f, y, w, y, gridP)
            y += step
        }
        c.drawLine(w / 2f, 0f, w / 2f, h, guideP)
        c.drawLine(0f, h / 2f, w, h / 2f, guideP)
    }
}
